We have provided some additional single-frame mpeg backgrounds for
developers to use in this folder. Look here in future releases for
other reusable art assets and tidbits!

Please see the tech note on using video backgrounds that is part of
the HME SDK, and refer to the Bananas Sample code to see an
example of using them in your Bananas based application.
