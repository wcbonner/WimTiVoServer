#!/bin/sh
#
# This script will run the SDK Factory using the launch file to 
# execute all samples.
#
# You must either have java in your path, or you must edit this script
# to use your installed java.
#
java -cp ../hme-host-sample.jar:samples.jar com.tivo.hme.host.sample.Main --launcher launcher.txt
