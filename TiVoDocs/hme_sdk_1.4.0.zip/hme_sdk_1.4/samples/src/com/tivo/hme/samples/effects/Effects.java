//////////////////////////////////////////////////////////////////////
//
// File: Effects.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.effects;

import java.awt.Color;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * Illustrates animation effects with ease on Views.
 *
 * When changing many properties of a view the change can be animated instead of
 * instant, with the change happening incrementally over a specified period.
 * 
 * The reciever will perform the animation with linear interpolation when ease
 * is set to 0 (or no ease at all). Adjusting the ease allows you to animate
 * with acceleration and deceleration.
 *
 * This sample shows how to use animation when changing the following properties
 * of a view:
 *
 * bounds
 * translate
 * transparency
 * scale
 * visible
 * translation
 * remove from parent view
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Effects extends Application implements Runnable
{
    // Each view is used for demonstrating a different property
    View bounds, translate, transparency, scale, visible;

    View content;         // Container for everything inset to title-safe
    View easeText;        // Displays the current ease value
    View timeText;        // Displays current animation animTime
    int ease;             // The current ease value
    int animTime = 1000;  // Animation time
    
    public void init(IContext context) throws Exception
    {
        super.init(context);
        //
        // Prepare our view & container
        //
        View root = getRoot();
        root.setResource(Color.white);
        content = new View(root, (SAFE_ACTION_H * 2), (SAFE_ACTION_V * 2),
                           640 - (SAFE_ACTION_H * 4), 480 - (SAFE_ACTION_V * 4));

        //
        // Create the views for each demonstration
        //
        easeText = new View(content, 300, 0, 190, 20);
        timeText = new View(content, 300, 20, 190, 20);        
        transparency = new Square(content, 0, 0, 90, 90,
                                  "Transparency", Color.magenta);
        visible = new Square(content, 100, 0, 90, 90, "Visible", Color.magenta);
        bounds = new Square(content, 300, 100, 90, 90, "Bounds", Color.magenta);
        translate = new View(content, 0, 100, 290, 90);
        new Square(translate, -300, 0, 600, 90, Color.green);
        new Square(translate, 0, 0, 90, 90, "Translate", Color.magenta);
        scale = new Square(content, 0, 200, 90, 90, "Scale", Color.magenta);

        //
        // Kick off the thread to update the effects animation
        //
        new Thread(this).start();
    }

    /**
     * The application is closing.  The thread will terminate because it watches
     * for the context to be set to null.
     */
    public synchronized void destroy()
    {
        notify();
    }
    
    /**
     * Arrow keys control the ease.  The animation resource is updated with the
     * new ease. The value of ease and animTime are updated on screen, but
     * since the settings don't take effect until the current animation ends
     * they are displayed in Red.
     */
    public boolean handleKeyPress(int code, long rawcode)
    {
        int deltaD = 0;
        int deltaE = 0;
        
        switch (code) {
          case KEY_UP:
          case KEY_DOWN:
            deltaD = ((code == KEY_DOWN) ? -250 : 250);
            break;
          case KEY_LEFT:
          case KEY_RIGHT:
            deltaE = ((code == KEY_LEFT) ? -10 : 10);
            break;
        }

        if (deltaD != 0 || deltaE != 0) {
            ease = Math.max(Math.min(ease + deltaE, 100), -100);
            animTime = Math.max(Math.min(animTime + deltaD, 9750), 1000);
            showSettings(Color.red);
        }

        return super.handleKeyPress(code, rawcode);
    }

    /**
     * Update the demo view animations and sleep until they are finished.
     * Then reverse the animations and do it again.
     */
    public void run()
    {
        boolean parity = false;
        while (!isApplicationClosing()) {
            parity = !parity;

            //
            // Create the animation resource from current settings This method
            // of creating the resource is the most efficient because the
            // receiver will use a cached resource if it has one already.
            //
            Resource anim = getResource("*" + animTime + ","
                                        + ((float)ease / 100f));

            //
            // Update the animations for each property, alternating. All of
            // these animations use the shared animation resource.
            //
            transparency.setTransparency(parity ? 1 : 0, anim);
            visible.setVisible(!parity, anim);
            translate.setTranslation(parity ? 200 : 0, 0, anim);
            scale.setScale(parity ? 1.5f : 1f, parity ? 1.5f : 1f, anim);

            if (parity) {
                // add and remove this square in the future specified by the
                // animation
                new Square(content, 200, 0, 90, 90,
                           "Remove", Color.magenta).remove(anim);
                bounds.setBounds(300, 150, 190, 190, anim);
            } else {
                bounds.setBounds(300, 100, 90, 90, anim);
            }

            //
            // Display the current animTime & ease in black to indicate it has
            // taken effect.
            //
            showSettings(Color.black);
            
            //
            // Must be called to update the display when changes are made from
            // another thread
            //
            flush();
                
            try {
                synchronized (this) {
                    wait(animTime);
                }
            } catch (InterruptedException e) {
                return;
            }
        }
    }


    /**
     * Display the value of the ease and animTime in the given color.
     */
    void showSettings(Color color)
    {
        easeText.setResource(createText("default-17.font", color,
                                        "Ease (use left/right) : " + ease),
                             RSRC_HALIGN_LEFT);

        timeText.setResource(createText("default-17.font", color,
                                        "Time (use up/down) : " + animTime),
                             RSRC_HALIGN_LEFT);
    }

    /**
     * This class handles the animated squares with text
     */
    static class Square extends View
    {
        View label;

        Square(View parent, int x, int y, int w, int h, Object bg)
        {
            super(parent, x, y, w, h);
            setResource(bg);
            label = new View(this, 0, 0, w, h);
        }
        
        Square(View parent, int x, int y, int w, int h, String title, Object bg)
        {
            this(parent, x, y, w, h, bg);
            label.setResource(createText("default-17.font", Color.white, title));
        }
    }
}
