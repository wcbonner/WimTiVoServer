//////////////////////////////////////////////////////////////////////
//
// File: Pictures.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.pictures;

import java.awt.Button;
import java.awt.Image;
import java.awt.MediaTracker;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.ImageIcon;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.interfaces.IArgumentList;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.Factory;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;
import com.tivo.hme.sdk.util.Ticker;

/**
 * Pictures
 * 
 * Run a slide show of pictures found in a directory. This sample shows how to:
 *
 *  - custom factory for reading command line arguments
 *  - dynamic image creation
 *  - scales images and uses resource flags
 *  - animation
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Pictures extends Application implements Ticker.Client
{
    // the media tracker reqires a component, so we use this button
    final static Button mediaTrackerComp = new Button();
    
    final static int SHOW_TIME = 4000; // how long the pictures is shown
    final static int FADE_TIME = 1250; // how long to perform the fade in/out
    
    View root;       // the root view
    View fg, bg;     // the foreground and background pictures
    
    ArrayList list;  // the list of pictures from the factory
    int index = -1;  // index into the list of images
    
    /**
     * Initialize the application.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        list = ((PicturesFactory)getFactory()).list;
        
        // save the root view for later
        root = getRoot();
        
        // create the bg first, because it's behind the fg
        bg = new View(root, 0, 0, root.getWidth(), root.getHeight());
        fg = new View(root, 0, 0, root.getWidth(), root.getHeight());
        
        Ticker.master.add(this, System.currentTimeMillis(), null);
    }
    
    /**
     * The tick method is used to advance to the next picture.
     **/
    public long tick(long tm, Object arg)
    {
        //
        // Check to see if the application has closed down
        // and return -1 so the ticker doesn't re-register us.
        //
        if (isApplicationClosing()) {
            return -1;
        }
        
        // advance to the next picture and show it
        index = (index + 1) % list.size();
        showPicture((String)list.get(index));
        
        // Since tick is called from another thread call flush to force hme to
        // write out any pending commands.
        flush();
        
        // tick again to advance to the next frame
        return System.currentTimeMillis() + SHOW_TIME;
    }
    
    /**
     * Display the given picture, performing a fade in. If there was a previous
     * image displayed, that image will be faded out.
     *
     * To fade out an image the resource is re-assigned to the bg and the
     * transparency is adjusted to go from opage to fully transparent.
     *
     * @param path - full path to a .jpg file
     * */
    void showPicture(String path)
    {
        // turn painting off while we twiddle things
        root.setPainting(false);
        try {
            // move the current image to the background view for fading out
            bg.setResource(fg.getResource(), RSRC_IMAGE_BESTFIT);
            
            // get a scaled instance of the image
            Image img = getScaledImage(path, getWidth(), getHeight());
            
            // stuff the scaled image into the fg
            fg.setResource(createImage(img), RSRC_IMAGE_BESTFIT);
            
            // Perform the CROSS FADE
            Resource anim = getResource("*" + FADE_TIME);
            fg.setTransparency(1.0f);         // start transparent, then fade IN
            fg.setTransparency(0.0f, anim);
            bg.setTransparency(0.0f);         // start opaque, then fade OUT
            bg.setTransparency(1.0f, anim);
        } finally {
            root.setPainting(true);
        }
    }
    
    /**
     * The image is only scaled if it is larger than 640x480, the HME maximum
     * image size. If the image is smaller the smaller image is sent and the
     * receiver, and scaled on the receiver.
     * 
     * @param path the full path to the image file to scale.
     * @param width the maximum width of the scaled image
     * @param height the maximum height of the scaled image.
     * @return Image scaled to best fit the given dimensions.
     */
    public static Image getScaledImage(String path, int width, int height) {
        //
        // use the swing imageIcon class to synchronously load the image
        //
        
        ImageIcon icon = new ImageIcon(path);
        Image img = icon.getImage();
        int imgW = icon.getIconWidth();
        int imgH = icon.getIconHeight();
        
        //
        // figure out the scale factor and the new size
        //
        
        float scale = Math.min((float) width / imgW, (float) height / imgH);
        if (scale > 1.0f) {
            scale = 1.0f;
        }
        int scaleW = (int)(imgW * scale);
        int scaleH = (int)(imgH * scale);
        
        //
        // Perform scaling if the image must be shrunk. We will send smaller
        // images over and let the receiver scale them up.
        //
        
        if (scale < 1.0f) {
            img = img.getScaledInstance(scaleW, scaleH, Image.SCALE_FAST);
            try {
                MediaTracker mt = new MediaTracker(mediaTrackerComp);
                mt.addImage(img, 0);
                mt.waitForAll();
            } catch(InterruptedException e) {
            }
        }
        
        return img;
    }
    
    
    /**
     * This shows how to use a Factor class to initialize shared data between
     * multiple running instances of your application.
     */
    public static class PicturesFactory extends Factory
    {
        ArrayList list = new ArrayList();
        
        protected void init(IArgumentList args)
        {
            if (args.getRemainingCount() != 1) {
                usage();
            }
            
            // grab the directory containing pictures from the argument list
            // and recursively scan it for all .jpg files.
            String root = args.shift();
            if (!new File(root).exists()) {
                System.out.println("Directory not found: " + root);
                usage();
            }
            
            find(root);
        }
        
        void usage()
        {
            System.err.println("Usage: Pictures <directory>");
            System.exit(1);
        }
        
        /**
         * Recursively scans for jpg files and loads the list
         * with full path names.
         */
        void find(String path)
        {
            File file = new File(path);
            if (file.isDirectory()) {
                if (path.length() > 0 && !path.endsWith("/")) {
                    path += "/";
                }
                String list[] = file.list();
                Arrays.sort(list);
                for (int i = 0; i < list.length; i++) {
                    find(path + list[i]);
                }
            } else if (path.toLowerCase().endsWith(".jpg")) {
                System.out.println("ADDING: " + path);
                list.add(path);
            }
        }
    }
}
