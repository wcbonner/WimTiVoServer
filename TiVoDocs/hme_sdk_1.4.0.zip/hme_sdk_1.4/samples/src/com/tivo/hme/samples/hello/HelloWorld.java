//////////////////////////////////////////////////////////////////////
//
// File: HelloWorld.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.hello;

import java.awt.Color;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;

/**
 * Displays "Hello, world!".
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class HelloWorld extends Application
{
    /**
     * Create the app.
     * @throws Exception
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        getRoot().setResource(createText("default-36-bold.font",
                                    Color.white, "Hello, world!"));
    }
}
