//////////////////////////////////////////////////////////////////////
//
// File: FontInfo.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.fontinfo;

import java.awt.Color;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * Displays basic font metrics returned in resourceInfo event.
 * Demonstrates using the metrics to size text vertically and horizontally.
 *
 * @author      Brigham Stevens
 */
public class FontInfo extends Application
{
    Resource.FontResource font;

    public void init(IContext context) throws Exception
    {
        super.init(context);

        // create the main view which will display the font info
        View fv = new FontView(getRoot());

        // create the font and add the view as a listener for it's events
        // Use new font flags to indicate to the reciever to send back metrics for this font
        font = (Resource.FontResource) createFont( "default.ttf", FONT_BOLD, 36,
                                                   FONT_METRICS_BASIC | FONT_METRICS_GLYPH );
        font.addHandler(fv);
    }

    public class FontView extends View {

        FontView(View parent)
        {
            super(parent, 0, 0, 640, 480);
        }

        public boolean handleEvent(HmeEvent event)
        {
            switch (event.getOpCode()) {
              case EVT_FONT_INFO:
                HmeEvent.FontInfo fi = (HmeEvent.FontInfo) event;

                // change the text displayed to contain the font info
                setResource(createText(font, Color.white,
                                       "Font Info:  default.ttf 36 Bold\n" +
                                       "height:     " + fi.getHeight()  + "\n" +
                                       "ascent:     " + fi.getAscent()  + "\n" +
                                       "descent:    " + fi.getDescent() + "\n" +
                                       "linegap:    " + fi.getLineGap() + "\n" +
                                       "l advance:  " + fi.getGlyphInfo('l').getAdvance() + "\n" +
                                       "M advance:  " + fi.getGlyphInfo('M').getAdvance()
                                 ),
                              RSRC_TEXT_WRAP);

                // resize the view vertically to exactly fit the text
                int newHeight = (int) fi.getHeight() * 8;
                int newY = 240 - newHeight/2;
                setBounds(0, newY, 640, newHeight);

                // create a header view that is sized to the exact top area above the font info
                View header = new View(getParent(),0 , 0, 640, newY);
                header.setResource(Color.gray);
                View txt = new View(header, 0, 0, 640, newY);
                txt.setResource(createText(font, Color.blue,"Header"));
                
                // create a footer view that is sized to the exact area below the font info
                View footer = new View(getParent(), 0, newY + newHeight, 640, newY);
                footer.setResource(Color.gray);

                // create a text resource and put in a view that is sized-to-fit the width
                String someText = "Program Your TV!\u00ae";
                int someTextW = fi.measureTextWidth(someText);

                // set the BG color behind the text
                View txt2bg = new View(footer, 0, 0, someTextW, newY);
                txt2bg.setResource(Color.red);

                // create the view that contains the text
                View txt2 = new View(footer, 0, 0, someTextW, newY);
                txt2.setResource(createText(font, Color.cyan,someText));

                // position the footer to the right of the text
                View txt3 = new View(footer, someTextW, 0, 640-someTextW, newY);
                txt3.setResource(createText(font, Color.blue,"Footer"));
                
                return true;
            }

            return false;
        }

    }
}
