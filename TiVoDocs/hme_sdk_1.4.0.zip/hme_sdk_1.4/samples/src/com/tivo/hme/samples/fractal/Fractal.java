//////////////////////////////////////////////////////////////////////
//
// File: Fractal.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.fractal;

import java.awt.image.BufferedImage;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.View;

/**
 * Displays a fractal. This sample illustrates:
 *
 *  - dynamically creating images
 *  - key presses
 *  - sounds
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Fractal extends Application
{
    Mandel mandel;

    /**
     * Create the app.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);

        mandel = new Mandel(getRoot(),
                            (getRoot().getWidth()  - 400) / 2,
                            (getRoot().getHeight() - 300) / 3,
                            400, 300);
    }

    /**
     * Handle key presses. Hitting keys will move/scale the fractal.
     */
    public boolean handleKeyPress(int code, long rawcode)
    {
	switch (code) {
          case KEY_THUMBSUP:
          case KEY_CHANNELUP:
          case KEY_FORWARD:
            mandel.scaleFrac(1 / 2.0);
            break;

          case KEY_THUMBSDOWN:
          case KEY_CHANNELDOWN:
          case KEY_REVERSE:
            mandel.scaleFrac(2.0);
            break;
            
          case KEY_UP:    mandel.moveFrac(0, -0.1); break;
          case KEY_DOWN:  mandel.moveFrac(0,  0.1); break;
          case KEY_LEFT:  mandel.moveFrac(-0.1, 0); break;
          case KEY_RIGHT: mandel.moveFrac( 0.1, 0); break;
	}
	return super.handleKeyPress(code, rawcode);
    }

    /**
     * A helper view that displays the fractal.
     */
    static class Mandel extends View
    {
        final static int ITERATIONS = 100;

        // offscreen image that we render the fractal into
        BufferedImage image;

        // color palette for the fractal
        int palette[];

        // fractal bounds on the complex plane
        double mx, my, mw, mh;

        Mandel(View parent, int x, int y, int width, int height)
        {
            super(parent, x, y, width, height);
            image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            //
            // setup palette
            //
            
            palette = new int[ITERATIONS + 1];
            for (int i = 0; i < ITERATIONS; ++i) {
                int distance = (i % 10) * 25;
                int r = distance;
                int g = 0;
                int b = distance;

                palette[i] = (((r & 0xFF) << 16) |
                              ((g & 0xFF) <<  8) |
                              ((b & 0xFF) <<  0));
            }
            palette[ITERATIONS] = palette[0];

            //
            // initial bounds
            //

            setFracBounds(-2, -1.5, 2.5, 2.75);
        }

        //
        // helpers for moving/scaling the fractal position
        //
        
        void moveFrac(double dxp, double dyp)
        {
            play("updown.snd");
            setFracBounds(mx + (dxp * mw), my + (dyp * mh), mw, mh);
        }

        void scaleFrac(double factor)
        {
            play(factor < 1 ? "left.snd" : "right.snd");
            setFracBounds(mx + (mw / 2.0) * (1.0 - factor),
                          my + (mh / 2.0) * (1.0 - factor),
                          mw * factor, mh * factor);
        }

        void setFracBounds(double mx, double my, double mw, double mh)
        {
            //
            // update the fractal
            //

            update(mx, my, mw, mh);
            
            //
            // Set the image as our resource. The awt image gets encoded as a
            // PNG and sent to the receiver.
            //
            
            setResource(createImage(image));
        }

        private void update(double mx, double my, double mw, double mh)
        {
            //
            // update the bounds
            //
            
            this.mx = mx;
            this.my = my;
            this.mw = mw;
            this.mh = mh;
            
            //
            // compute the image
            //
            
            for (int y = 0; y < getHeight(); ++y) {
                double pY = my + mh * ((double)y / (double)getHeight());
                for (int x = 0; x < getWidth(); ++x) {
                    double iX = 0;
                    double iY = 0;
                    double pX = mx + mw * ((double)x / (double)getWidth());

                    int loop;
                    for (loop = 0; loop < ITERATIONS; ++loop) {
                        double nX = iX * iX - iY * iY + pX;
                        iY = 2.0 * iX * iY + pY;
                        iX = nX;
                        if (iX * iX + iY * iY > 4) {
                            break;
                        }
                    }
                    image.setRGB(x, y, palette[loop]);
                }
            }
        }
    }
}
