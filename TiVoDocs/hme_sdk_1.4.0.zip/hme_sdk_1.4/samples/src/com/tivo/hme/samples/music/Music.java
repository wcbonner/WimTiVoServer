//////////////////////////////////////////////////////////////////////
//
// File: Music.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.music;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.tivo.hme.interfaces.IArgumentList;
import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.Factory;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.StreamResource;
import com.tivo.hme.sdk.View;

/**
 * A music player. This sample illustrates:
 *
 *  - mp3 playback with eventing
 *  - custom factory for serving mp3 files (w/ duration header)
 *  - list widget
 *  - focus
 *  - sounds
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Music extends Application
{
    // list of tracks
    MusicList list;
    
    // view that contains the currently playing track
    Track track;
    
    // which track is playing
    int playing = -1;
    
    // when did the last key press occur
    long lastKeyPress;
    
    /**
     * Create the app.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        list = new MusicList(getRoot(), 64, 40, 640 - 64*2, 480 - 150, 27);
        track = new Track(getRoot(), 64, list.getY() + list.getHeight() + 10, 640 - 64*2, 60);
        
        // populate our list using the files read by the factory
        list.addAll(((MusicFactory)getFactory()).list);
        
        // Give the list widget focus. Key presses will go to the list by
        // default. If the list doesn't handle the key press it'll bubble up to
        // the app.
        setFocus(list);
    }
    
    /**
     * Play a track. Index is a position in the list.
     */
    void play(int index)
    {
        if (index != playing) {
            playing = index;
            
            //
            // Construct the URI to send to the receiver. The receiver will
            // connect back to our factory and ask for the file. The URI
            // consists of:
            //
            // (our base URI) + (the track's path name)
            //
            
            String url = getApp().getContext().getBaseURI().toString();
            try {
                url += URLEncoder.encode((String)list.get(index), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            track.playTrack(url);
        }
    }
    
    
    //
    // event handlers
    //
    
    /**
     * Handle key presses - play/pause tracks.
     */
    public boolean handleKeyPress(int code, long rawcode)
    {
        switch (code) {
            case KEY_PLAY:
            case KEY_SELECT: {
                play("select.snd");
                play(list.getSelectedIndex());
                return true;
            }
            
            case KEY_PAUSE: {
                track.pauseTrack();
                break;
            }
            
            case KEY_SLOW: {
                track.slowTrack();
                break;
            }

            case KEY_FORWARD: {
                track.fastForward();
                break;
            }
            case KEY_REVERSE: {
                track.rewind();
                break;
            }
        }
        return super.handleKeyPress(code, rawcode);
    }
    
    /**
     * Handle events from the mp3 stream.
     */
    public boolean handleEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
        
        //
        // The stream will send resouce info events while it plays. The SDK
        // will automatically generate a synthetic RSRC_STATUS event whenever
        // the status of the stream changes.
        //
        // If the track finishes, start playing the next one.
        //
        
        case StreamResource.EVT_RSRC_STATUS: {
            HmeEvent.ResourceInfo info = (HmeEvent.ResourceInfo)event;
            if (info.getStatus() >= RSRC_STATUS_CLOSED) {
                // the track finished - what next?
                
                if (list.size() == 1) {
                    playing = -1;
                    return super.handleEvent(event);
                }
                
                // advance
                int index = playing + 1;
                if (index == list.size()) {
                    index = 0;
                }
                
                // if the user hasn't touched the list recently, move the
                // selector to reflect the new track.
                if (System.currentTimeMillis() - lastKeyPress > 5000) {
                    list.select(index, true);
                }
                
                // now play the new track
                play(index);
            }
            return true;
        }
        }
        return super.handleEvent(event);
    }
    
    /**
     * All events received by the app are sent through dispatchEvent. This is a
     * convenient place to listen for ALL key presses since they hit this method
     * regardless of which view has the focus.
     */
    protected void dispatchEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
        case EVT_KEY:
            lastKeyPress = System.currentTimeMillis();
            break;
        }
        super.dispatchEvent(event);
    }
    
    /**
     * A list widget that contains lines of text and a blue selector.
     */
    static class MusicList extends BaseList
    {
        MusicList(View parent, int x, int y, int width, int height, int itemHeight)
        {
            super(parent, x, y, width, height, itemHeight);
        }
        
        /**
         * Create the blue selector.
         */
        protected View createSelector(View parent, int w, int h)
        {
            View v = new View(parent, 0, 0, w, h);
            v.setResource(Color.blue);
            return v;
        }
        
        /**
         * Create a view to display a row. If the text is too long, truncate it.
         */
        protected View createRow(View parent, int x, int y, int w, int h, int index)
        {
            String str = get(index).toString();
            int i = str.lastIndexOf('/');
            if (i != -1) {
                str = str.substring(i + 1);
            }
            if (str.endsWith(".mp3")) {
                str = str.substring(0, str.length() - 4);
            }
            if (str.length() > 50) {
                str = "..." + str.substring(str.length() - 50);
            }
            
            View v = new View(parent, x, y, w, h);
            v.setResource(createText("default-24.font", Color.white,
                    str), RSRC_HALIGN_LEFT);
            return v;
        }
    }
    
    /**
     * A view that contains the currently playing track. The view contains the
     * mp3 stream and receives events from it. The view displays the events as
     * text strings and therefore act as a simple progress indicator.
     */
    static class Track extends View
    {
        View label;
        boolean slowed = false;
        
        Track(View parent, int x, int y, int width, int height)
        {
            super(parent, x, y, width, height);
            label = new View(this, 0, 0, width, height);
        }
        
        /**
         * Play a url
         */
        void playTrack(String url)
        {
            Resource resource = getResource();
            // stop the current stream
            if (resource != null) {
                resource.remove();
            }
            // start the new one
            setResource(createStream(url, null, true));
        }
        
        /**
         * Pause the current stream.
         */
        void pauseTrack()
        {
            Resource resource = getResource();
            if (resource != null) {
                ((StreamResource)resource).pause();
            }
        }
        
        /**
         * Slow the current stream.
         */
        void slowTrack()
        {
            float speed = 1.0f;
            Resource resource = getResource();
            if (resource != null) 
            {
                if (!slowed)
                {
                    speed = 0.5f;
                }
                ((StreamResource)resource).setSpeed(speed);
                slowed = !slowed;
            }
        }
        
        boolean isSlowed()
        {
            return slowed;
        }

        // keeps track of current FF/REW speed
        int speed_idx = 3;
        float[] speeds = {-60.0f, -15.0f, -3.0f, 1.0f, 3.0f, 15.0f, 60.0f};

        /**
         * Fast forward the current stream.
         */
        void fastForward()
        {
            Resource resource = getResource();
            if (resource != null) 
            {
                if (speed_idx < 6)
                {
                    speed_idx++;
                    if (speed_idx == 4) {
                        play("speedup1.snd");
                    } else if (speed_idx == 5) {
                        play("speedup2.snd");
                    } else if (speed_idx == 6) {
                        play("speedup3.snd");
                    } else {
                        play("slowdown1.snd");
                    }
                                            
                }
                else
                {
                    // if currently going as fast as we can, drop back to play, to mimic video FF behavior
                    speed_idx = 3;
                    play("slowdown1.snd");
                }
                ((StreamResource)resource).setSpeed(speeds[speed_idx]);
            }
        }
//        systemIDs.put("slowdown1.snd",  new Integer(ID_SLOWDOWN1_SOUND));
//        systemIDs.put("speedup1.snd",   new Integer(ID_SPEEDUP1_SOUND));
//        systemIDs.put("speedup2.snd",   new Integer(ID_SPEEDUP2_SOUND));
//        systemIDs.put("speedup3.snd",   new Integer(ID_SPEEDUP3_SOUND));
     
        /**
         * rewind the current stream.
         */
        void rewind()
        {
            Resource resource = getResource();
            if (resource != null) 
            {
                if (speed_idx > 0)
                {
                    speed_idx--;
                    if (speed_idx == 2) {
                        play("speedup1.snd");
                    } else if (speed_idx == 1) {
                        play("speedup2.snd");
                    } else if (speed_idx == 0) {
                        play("speedup3.snd");
                    } else {
                        play("slowdown1.snd");
                    }
                }
                else
                {
                    // if currently going as fast as we can, drop back to play, to mimic video REW behavior
                    speed_idx = 3;
                    play("slowdown1.snd");
                }
                ((StreamResource)resource).setSpeed(speeds[speed_idx]);
            }
        }
        
        /**
         * Stuff the events into label.
         */
        public boolean handleEvent(HmeEvent event)
        {
            label.setResource(createText("default-18-bold.font", Color.yellow, event.toString()), RSRC_HALIGN_CENTER | RSRC_TEXT_WRAP);
            return super.handleEvent(event);
        }
    }

    /**
     * A custom factory for serving up mp3 files. MusicFactory will recursively
     * scan a folder for mp3 files and stuff the files into list. It will serve
     * up these files from the disk.
     *
     * Whenever it serves an mp3 file it will send the duration as a special
     * http header. Otherwise there is no way for the receiver to know the mp3
     * duration.
     *
     * Note that the MusicFactory stores a list of paths that are RELATIVE to
     * the root directory. These same relative paths are used when creating
     * streams and come back to the factory inside getStream. We use relative
     * paths because it's more secure to only serve files inside the root
     * directory. This sample could be made even more secure by checking for
     * ".." and other nefarious paths inside getMP3StreamFromURI.
     */
    static public class MusicFactory extends Factory
    {
        String root;
        ArrayList list = new ArrayList();
        
        /**
         * Create the factory - scan the folder.
         */
        protected void init(IArgumentList args)
        {
            try {
                args.checkForIllegalFlags();
                if (args.getRemainingCount() != 1) {
                    usage();
                }
            } catch (IArgumentList.BadArgumentException e) {
                usage();
            }
            
            root = args.shift();
            if (!new File(root).exists()) {
                System.out.println("Directory not found: " + root);
                usage();
            }
            find("");
        }
        
        /**
         * Print usage and exit.
         */
        void usage()
        {
            System.err.println("Usage: Music <directory>");
            System.err.println("For example 'Music c:/mymusic' will find all music contained in the");
            System.err.println("mymusic directory.");
            System.exit(1);
        }
        
        /**
         * Recursively search for music.
         */
        void find(String path)
        {
            File file = new File(root, path);
            if (file.isDirectory()) {
                if (path.length() > 0 && !path.endsWith("/")) {
                    path += "/";
                }
                String list[] = file.list();
                Arrays.sort(list);                
                for (int i = 0; i < list.length; i++) {
                    find(path + list[i]);
                }
            } else if (path.toLowerCase().endsWith(".mp3") || path.toLowerCase().endsWith(".mpg")) {
                getList().add(path);
                System.out.println("ADDED: " + path);
            }
        }
        
        private List getList()
        {
            if (this.list == null)
            {
                this.list = new ArrayList();
            }
            return this.list;
        }

        /* (non-Javadoc)
         * @see com.tivo.hme.sdk.MP3Factory#getMP3StreamFromURI(java.lang.String)
         */
        public InputStream getStream(String uri) throws IOException 
        {
            File file = new File(root, URLDecoder.decode(uri, "UTF-8"));
            if (file.exists()) 
            {
                InputStream in = new FileInputStream(file);
                return in;
            }
            else
            {
                return super.getStream(uri);
            }
        }
    }
}
