//////////////////////////////////////////////////////////////////////
//
// File: Animate.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.animate;

import java.awt.Color;
import java.util.Random;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * A simple demonstration of how to perform animations with View classes. This
 * sample shows how to use Application.sendEvent(HmeEvent,AnimResource) to
 * receive a notification when the animation request has completed.
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Animate extends Application
{
    final static Random random = new Random(System.currentTimeMillis());

    View content;
    SpriteView sprites[] = new SpriteView[16];

    public void init(IContext context) throws Exception
    {
        super.init(context);
        
        View root = getRoot();
        
        // create a container view that will hold everything else, sized to the
        // safe action bounds.
        content = new View(root, SAFE_ACTION_H / 2, SAFE_ACTION_V / 2,
                           root.getWidth() - SAFE_ACTION_H,
                           root.getHeight() - SAFE_ACTION_V);
        
        // create the set of animated squares
        for(int i = 0; i < sprites.length; ++i) {
            sprites[i] = new SpriteView(content, i,
                                        random.nextInt(content.getWidth()),
                                        random.nextInt(content.getHeight()),
                                        8 + random.nextInt(64),
                                        8 + random.nextInt(64));
        }
    }

    /**
     * Listen for our special "animation ended" event.
     */
    public boolean handleEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
          case EVT_KEY: {
              HmeEvent.Key e = (HmeEvent.Key)event;
              switch (e.getCode()){
                case KEY_TIVO:
                  int index = (int)e.getRawCode();
                  sprites[index].animate();
                  return true;
              }
          }
        }
        return super.handleEvent(event);
    }

    class SpriteView extends View
    {
        int index;
        
        public SpriteView(View parent, int index, 
                          int x, int y, int width, int height)
        {
            super(parent, x, y, width, height);
            this.index = index;

            setResource(new Color(random.nextInt(0xffffff)));

            // start animating
            animate();
        }

        /**
         * Move the sprite and send an event when we're done.
         **/
        void animate()
        {
            int speed = 250 + random.nextInt(5000);
            Resource anim = getResource("*" + speed);
            
            int destX = random.nextInt(content.getWidth());
            int destY = random.nextInt(content.getHeight());
            setLocation(destX, destY, anim);


            //
            // send a special event
            //
            
            HmeEvent evt = new HmeEvent.Key(getApp().getID(), 0,
                                            KEY_TIVO, index);
            sendEvent(evt, anim);
        }
    }
}