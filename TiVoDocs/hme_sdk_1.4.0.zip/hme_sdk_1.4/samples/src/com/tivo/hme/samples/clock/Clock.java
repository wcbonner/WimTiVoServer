//////////////////////////////////////////////////////////////////////
//
// File: Clock.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.clock;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.View;

/**
 * A clock. This sample illustrates:
 *
 *  - animation in a separate thread
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Clock extends Application implements Runnable
{
    final static SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    
    View time[];

    /**
     * Create the app.
     * @throws Exception
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        getRoot().setResource(Color.white);
        
        time = new View[2];
        for (int i = 0 ; i < time.length ; i++) {
            time[i] = new View(getRoot(), 0, 100, getWidth(), 280);
        }
        
        // start a separate thread to update the time
        new Thread(this).start();
    }
    
    /**
     * Wake up every so often and update the time.
     */
    public void run()
    {
	long tm = System.currentTimeMillis();
	int n = 0;
	while (!isApplicationClosing()) {
	    // fade out the old time
	    time[n].setTransparency(1, getResource("*750"));

            // switch to the other view
	    n = (n + 1) % 2;

            // show the current time
	    time[n].setResource(createText("default-96-bold.font", Color.black,
                                           dateFormat.format(new Date())),
                                RSRC_HALIGN_CENTER);
	    time[n].setTransparency(0, getResource("*750"));

	    // Manually flush HME commands. This has to be done since we're
	    // issuing commands in a separate thread.
	    flush();

	    // now sleep
	    tm += 1000;
	    long sleep = tm - System.currentTimeMillis();
	    if (sleep > 0) {
		try {
		    Thread.sleep(sleep);
		} catch (InterruptedException e) {
		    break;
		}
	    }
	}
    }
}
