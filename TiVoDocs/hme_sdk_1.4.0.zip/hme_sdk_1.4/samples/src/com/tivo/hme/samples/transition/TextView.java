//////////////////////////////////////////////////////////////////////
//
// File: TextView.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.transition;

import java.awt.*;

import com.tivo.hme.sdk.*;

public class TextView extends View
{
    public Resource fg;
    public Resource font;
    public Resource text;
    public int flags;
    public String value;
    
    public TextView(View parent, int x, int y, int width, int height)
    {
	super(parent, x, y, width, height);

	fg = createColor(Color.white);
	flags = RSRC_HALIGN_CENTER;
    }

    //
    // accessors
    //

    public void setBounds(int x, int y, int width, int height, Resource animation)
    {
	boolean repaint = (this.getWidth() != width || this.getHeight() != height);
	super.setBounds(x, y, width, height, animation);
	if (repaint) {
	    repaint();
	}
    }

    public Resource getForeground()
    {
	Resource fg = this.fg;
	if (fg == null) {
	    this.fg = fg = createColor(Color.white);
	}
	return fg;
    }
    
    public Resource getFont()
    {
	Resource font = this.font;
	if (font == null) {
	    this.font = font = getResource("default-36.font");
	}
	return font;
    }
    public int getFlags()		{ return flags; }
    public String getValue()		{ return value; }

    public void setForeground(Resource fg)
    {
	if (this.fg == fg) {
	    return;
	}
	this.fg = fg;
	repaint();
    }

    public void setFont(String fontStr)
    {
        setFont(getResource(fontStr));
    }

    public void setFont(Resource font)
    {
	if (this.font == font) {
	    return;
	}
	this.font = font;
	repaint();
    }
    
    public void setFlags(int flags)
    {
	if (this.flags == flags) {
	    return;
	}
	this.flags = flags;
	repaint();
    }
    
    public void setValue(Object obj)
    {
        String nvalue = (obj != null) ? obj.toString() : null;
	if (this.value == null) {
	    if (nvalue == null) {
		return;
	    }
	} else if (this.value.equals(nvalue)) {
	    return;
	}
	this.value = nvalue;
	repaint();
    }

    protected void repaint()
    {
    	String str = (value == null) ? "" : value;
    	text = createText( getFont(), getForeground(), str );
        setResource(text, flags);
    }

    protected void toString(StringBuffer buf)
    {
	super.toString(buf);
	buf.append(",\"").append(value).append("\"");
    }
}
