//////////////////////////////////////////////////////////////////////
//
// File: BaseList.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.music;

import java.util.*;
import com.tivo.hme.sdk.*;

/**
 * A very simple list widget. BaseList contains a list of elements (Objects) and
 * a list of rows that correspond to those elements (Rows). BaseList will call
 * createRow() when it needs to display an object. The selector is a view that
 * sits behind the element rows and is used to hilite the currently selected
 * row.
 *
 * BaseList scrolls itself to display particular rows using setTranslation. For
 * example, if the user hits KEY_CHANNELDOWN the list will usually scroll
 * down one screen height.
 *
 * BaseList implements java.util.List and can be used just like any other
 * List. The internal methodology is pretty simple. Each of the List methods
 * (add/remove/etc.) updates the elements/rows lists and then calls update() to
 * fix up the BaseList.
 *
 * To use BaseList:
 *  - override createSelector and createRow
 *  - give it focus or send it key presses
 *  
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public abstract class BaseList extends View implements List
{
    // arrays of elements + rows
    ArrayList elements;
    ArrayList rows;
    
    // geometry
    int rowHeight;
    int nVisibleRows;
    
    // selector view that sits behind the rows
    View selector;

    // the current "top" row displayed within the list. As the list scrolls down
    // top will move down as well.
    int top;

    // the currently selected row
    int selected;

    // when elements are added in the middle of the visible screen, the "dirty"
    // index keeps track of which rows must be moved up.
    int dirty;

    /**
     * Creates a new BaseList instance.
     *
     * @param parent parent
     * @param x x
     * @param y y
     * @param width width
     * @param height height
     * @param rowHeight The height of each row contained in the list.
     */
    public BaseList(View parent, int x, int y, int width, int height, int rowHeight)
    {
	super(parent, x, y, width, height);

	this.rowHeight = rowHeight;
        nVisibleRows = height / rowHeight;

        elements = new ArrayList();
        rows = new ArrayList();
        
        // create the selector first, so it draws BEHIND the rows
        selector = createSelector(this, width, rowHeight);
        selector.setVisible(false);

        clear();
    }

    //
    // subclasses should override these
    //
    
    /**
     * Create the selector for the list. The selector floats behind the
     * rows. BaseList will move it around as different items are selected.
     *
     * @param parent use this as the parent for your new view
     * @param w use this as the width for your new view
     * @param h use this as the height for your new view
     * @return the new selector
     */
    protected abstract View createSelector(View parent, int w, int h);
    
    /**
     * Create a row for the given element. For example, you could create a view
     * with the given bounds and then set its resource to be a text resource
     * based on the element at index.
     *
     * @param parent use this as the parent for your new view
     * @param x use this as the x coord for your new view
     * @param y use this as the x coord for your new view
     * @param w use this as the width for your new view
     * @param h use this as the height for your new view
     * @param index the index for the row
     * @return the new row
     */
    protected abstract View createRow(View parent, int x, int y, int w, int h, int index);

    //
    // accessors
    //

    /**
     * Get the index of the currently selected row.
     *
     * @return the index
     */
    public int getSelectedIndex()
    {
        return selected;
    }

    /**
     * Select a row.
     * 
     * @param index the row to select
     * @param animate If true, animate the list as we move to the new row.
     */
    public void select(int index, boolean animate)
    {
        selected = index;
        int size = size();
        if (size == 0) {
            selected = -1;
        } else if (selected < 0) {
            selected = 0;
        } else if (selected >= size) {
            selected = size - 1;
        }
        update(animate);
    }

    /**
     * Add an element to a sorted list.
     *
     * @param element the element to add
     */
    public void addSorted(Object element)
    {
	int low = 0;
        int high = size();
        while (low < high) {
            int mid = (low + high) / 2;
            int cmp = ((Comparable)element).compareTo(get(mid));
            if (cmp > 0) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
	add(low, element);
    }
    
    /**
     * Update the list, no animation.
     */
    void update()
    {
        update(false);
    }

    /**
     * If necessary, scrolls the list to show the currently selected row,
     * creates new row views to wrap the elemenst that are currently visible,
     * and move the selector view to indicate which row is currently selected.
     *
     * @param animate a <code>boolean</code> value
     */
    void update(boolean animate)
    {
        setPainting(false);
        try {
            Resource anim = animate ? getResource("*200") : null;

            if (selected == -1 && size() > 0) {
                selected = 0;
            }
        
            //
            // 1. update "top" so that selected is still visible
            //

            // 0 <= top <= size() - nVisibleRows
            top = Math.max(Math.min(top, size() - nVisibleRows), 0);

            int max = Math.min(top + nVisibleRows, size()) - 1;
            if (selected < top) {
                top = Math.max(0, selected);
            } else if (selected > max) {
                int end = Math.min(selected + 1, size());
                top = Math.max(end - nVisibleRows, 0);
            }
            max = Math.min(top + nVisibleRows, size()) - 1;
        
            //
            // 2. populate rows and put them at the correct height
            //

            for (int index = top; index <= max; ++index) {
                View v = (View)rows.get(index);
                if (v == null) {
                    v = createRow(this, 0, index * rowHeight,
                                  getWidth(), rowHeight, index);
                    rows.set(index, v);
                } else {
                    v.setLocation(v.getX(), index * rowHeight);
                }
            }

            //
            // 3. fix "dirty" rows
            //

            if (dirty != -1) {
                max = Math.min(dirty + nVisibleRows, size()) - 1;
                for (int index = dirty; index <= max; ++index) {
                    View v = (View)rows.get(index);
                    if (v != null) {
                        v.setLocation(v.getX(), index * rowHeight);
                    }
                }
                dirty = -1;
            }

            //
            // 4. translate to the right location
            //

            setTranslation(0, -top * rowHeight, anim);

            //
            // 5. move the selector
            //

            if (selected >= 0) {
                selector.setVisible(true);            
                selector.setLocation(0, selected * rowHeight, anim);
            } else {
                selector.setVisible(false);
            }
        } finally {
            setPainting(true);
        }
    }

    //
    // event handlers
    //
    
    /**
     * Handle key presses.
     */
    public boolean handleKeyPress(int code, long rawcode)
    {
        int delta = 0;
	switch (code) {
	  case KEY_UP:          delta = -1;                break;
          case KEY_DOWN:        delta =  1;                break;
	  case KEY_CHANNELUP:   delta = -1 * nVisibleRows; break;
          case KEY_CHANNELDOWN: delta =      nVisibleRows; break;
        }
        if (delta != 0) {
            if (selected == -1) {
                play("bonk.snd");
            } else {
                play("updown.snd");
                
                boolean animate = true;
                
                int max = size() - 1;
                int nselected = selected + delta;
                if (nselected < 0) {
                    // scrolled above the first row in the list. Either jump to
                    // the first row or wrap around to the LAST row.
                    if (selected != 0) {
                        nselected = 0;
                    } else {
                        animate = false;
                        nselected = max;
                    }
                } else if (nselected > max) {
                    // scrolled below the last row in the list. Either jump to
                    // the last row or wrap around to the FIRST row.
                    if (selected != max) {
                        nselected = max;
                    } else {
                        animate = false;
                        nselected = 0;
                    }
                } else {
                    // If the user hit channel up/down, move the top of the list
                    // too.
                    switch (code) {
                      case KEY_CHANNELUP:
                      case KEY_CHANNELDOWN:
                        top += delta;
                        break;
                    }
                }

                // obey the new selection, with animation.
                select(nselected, animate);
            }
            return true;
        }
	return super.handleKeyPress(code, rawcode);
    }

    /**
     * Handle key repeats for some keys.
     */
    public boolean handleKeyRepeat(int code, long rawcode)
    {
	switch (code) {
	  case KEY_UP:
	  case KEY_DOWN:
	  case KEY_CHANNELUP:
	  case KEY_CHANNELDOWN:
	    return handleKeyPress(code, rawcode);
	}
	return super.handleKeyRepeat(code, rawcode);
    }

    //
    // List implemenation
    //
    // These aren't individually commented - see the List interface for
    // details. The basic idea here is to modify the internal lists
    // (elements/rows) as necessary and then call update() to reflect the new
    // state. It's important to call update() whenever the list changes because
    // otherwise nothing happens on screen.
    //
    // Many functions call add0/remove0 repeatedly, and then call the more
    // expensive update() when the operation is complete.
    //

    public int size()
    {
        return elements.size();
    }

    public boolean isEmpty()
    {
        return elements.isEmpty();
    }

    public boolean contains(Object o)
    {
        return elements.contains(o);
    }

    public Iterator iterator()
    {
        return new Itr();
    }

    public Object[] toArray()
    {
        return elements.toArray();
    }
    
    public Object[] toArray(Object a[])
    {
        return elements.toArray(a);
    }
    
    public boolean add(Object o)
    {
        add(size(), o);
        return true;
    }

    public boolean remove(Object o)
    {
        int index = elements.indexOf(o);
        if (index == -1) {
            return false;
        }
        remove(index);
        return true;
    }

    public boolean containsAll(Collection c)
    {
        return elements.containsAll(c);
    }

    public boolean addAll(Collection c)
    {
        return addAll(elements.size(), c);
    }

    public boolean addAll(int index, Collection c)
    {
        int len = c.size();
        if (len == 0) {
            return false;
        }
        Object obj[] = c.toArray();
        for (int i = obj.length; i-- > 0;) {
            add0(index, obj[i]);
        }
        update();
        return true;
    }

    public boolean removeAll(Collection c)
    {
        boolean modified = false;
        for (Iterator i = c.iterator(); i.hasNext(); ) {
            int index = elements.indexOf(i.next());
            if (index != -1) {
                remove0(index);
                modified = true;
            }
        }
        return modified;
    }

    public boolean retainAll(Collection c)
    {
        ArrayList toRemove = new ArrayList();
        for (Iterator i = iterator(); i.hasNext(); ) {
            Object obj = i.next();
            if (!c.contains(obj)) {
                toRemove.add(obj);
            }
        }
        return removeAll(toRemove);
    }

    public void clear()
    {
        for (Iterator i = rows.iterator(); i.hasNext(); ) {
            View v = (View)i.next();
            if (v != null) {
                // we have to remove() old views                
                v.remove();
            }
        }
        elements.clear();
        rows.clear();
        
        selected = -1;
        top = 0;
        dirty = -1;
        
        update();
    }

    public boolean equals(Object o)
    {
        return (o instanceof BaseList) && ((BaseList)o).elements.equals(o);
    }

    public int hashCode()
    {
        return elements.hashCode();
    }

    public Object get(int index)
    {
        return elements.get(index);
    }

    public Object set(int index, Object element)
    {
        Object obj = elements.set(index, element);
        View v = (View)rows.set(index, null);
        if (v != null) {
            // we have to remove() old views
            v.remove();
        }
        update();
        return obj;
    }

    public void add(int index, Object element)
    {
        add0(index, element);
        update();
    }

    public Object remove(int index)
    {
        Object o = remove0(index);
        update();
        return o;
    }

    public int indexOf(Object o)
    {
        return elements.indexOf(o);
    }

    public int lastIndexOf(Object o)
    {
        return elements.lastIndexOf(o);
    }

    // add0/remove0 are low level helprs that update selected/top/dirty but
    // don't call update()

    void add0(int index, Object element)
    {
        if (index <= selected) {
            ++selected;
        }
        if (index <= top) {
            ++top;
        }

        // update the dirty index
        if (dirty == -1) {
            dirty = index;
        } else if (index <= dirty) {
            ++dirty;
        }
        
        elements.add(index, element);
        rows.add(index, null);
    }

    Object remove0(int index)
    {
        if (index < selected) {
            --selected;
        }
        if (index < top) {
            --top;
        }

        Object o = elements.remove(index);
        View v = (View)rows.remove(index);
        if (v != null) {
            // we have to remove() old views            
            v.remove();
        }
        return o;
    }

    //
    // unsupported...
    //
    
    public ListIterator listIterator()
    {
        throw new UnsupportedOperationException();
    }

    public ListIterator listIterator(int index)
    {
        throw new UnsupportedOperationException();        
    }

    public List subList(int fromIndex, int toIndex)
    {
        throw new UnsupportedOperationException();        
    }

    //
    // Iterator
    //

    private class Itr implements Iterator
    {
	int cursor = 0;
	int lastRet = -1;

	public boolean hasNext()
        {
	    return cursor != size();
	}

	public Object next()
        {
	    try {
		Object next = get(cursor);
		lastRet = cursor++;
		return next;
	    } catch(IndexOutOfBoundsException e) {
		throw new NoSuchElementException();
	    }
	}

	public void remove()
        {
	    if (lastRet == -1) {
		throw new IllegalStateException();
            }

	    try {
		BaseList.this.remove(lastRet);
		if (lastRet < cursor) {
		    cursor--;
                }
		lastRet = -1;
	    } catch(IndexOutOfBoundsException e) {
		throw new ConcurrentModificationException();
	    }
	}
    }
}
