//////////////////////////////////////////////////////////////////////
//
// File: VideoBackground.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.videobackground;

import java.awt.Color;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.View;

/**
 * Demonstrates how to use an mpeg video background as a background.
 *
 * A video background is a small mpeg movie, or a jpeg file that has been
 * converted to a single frame mpeg. Using a video background as a background
 * may free up rendering hardware in the TiVo DVR, and may be a useful technique
 * for some applications.
 *
 * Currently HME only supports single frame mpeg movie as a video background.
 *
 * Please see TechNote #001 in the SDK for more information on video
 * backgrounds.
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class VideoBackground extends Application
{
    View root;
    
    /**
     * Create the appplication.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        // save the root view (we use it later)
        root = getRoot();

        //
        // Set the mpeg file as the resource of the root view.  You can display
        // a video background in any view, but the coordinate space defined by
        // the view is ignored, the mpgeg will be displayed at 0,0 in global
        // screen coordinates.
        //
        root.setResource("myloop.mpg");

        //
        // Display some text with a drop shadow above the video background
        //
        View bg = new View(root, 2, 2, root.getWidth(), root.getHeight());
        View fg = new View(root, 0, 0, root.getWidth(), root.getHeight());

        bg.setResource(createText("default-20-bold.font",
                                  Color.black, "The picture is a movie!"));
        
        fg.setResource(createText("default-20-bold.font",
                                  Color.yellow, "The picture is a movie!"));
    }

    /**
     * This event handler looks for device info in order to substitute a jpeg
     * image as a background instead of the mpeg. Without this the root view in
     * the simulator the root would be left with a black background.
     *
     * This code and extra jpeg image are meant to be removed from a shipping
     * application!
     *
     * REMIND: This is only needed by developers while using the simulator!
     */
    public boolean handleEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
          case EVT_DEVICE_INFO:
            HmeEvent.DeviceInfo info = (HmeEvent.DeviceInfo)event;

            //
            // If we are running in the simulator display jpg.
            //
            String platform = (String)info.getMap().get("platform");
            if (platform != null && platform.startsWith("sim-")) {
                root.setResource("myloop.jpg");
            } 

            //
            // Have you ever wondered what is inside a device info event?
            //
            System.out.println(event);
            break;
        }
        return super.handleEvent(event);
    }
}
