//////////////////////////////////////////////////////////////////////
//
// File: Weather.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.weather;

import java.awt.Color;
import java.util.Random;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.interfaces.IArgumentList;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.Factory;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * Display the weather, updated periodically from a noaa.gov RSS feed.
 *
 *  - custom factory for command line arguments
 *  - data driven app
 *  - animation
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Weather extends Application implements Runnable
{
    final static Random random = new Random(System.currentTimeMillis());
    
    String url;
    View views[] = new View[3];
    
    /**
     * Create the app.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        //
        // Build the URL using the station name.
        //

        url = ("http://www.nws.noaa.gov/data/current_obs/" +
               ((WeatherFactory)getFactory()).station +
               ".rss");

        View root = getRoot();
        View content = new View(root, SAFE_ACTION_H, SAFE_ACTION_V,
                                root.getWidth() - SAFE_ACTION_H * 2,
                                root.getHeight() - SAFE_ACTION_V * 2);

        //
        // Create the three text views and start them moving. Note that each
        // view lives within its own portion of the screen.
        //

        int widths[] =  { 500, 400, 400 };
        int heights[] = {  70,  70, 100 };
        
        int panelHeight = content.getHeight() / views.length;
        for (int i = 0; i < views.length; ++i) {
            View panel = new View(content, 0, i * panelHeight,
                                  content.getWidth(), panelHeight);
            views[i] = new View(panel, 50, 50, widths[i], heights[i]);
            animate(i);
        }

        // go!
        new Thread(this).start();
    }

    /**
     * Overridden to notify our separate thread when the app is closed.
     */
    public synchronized void destroy()
    {
        // call notify() to wake up the wait() inside run()
        notify();
    }

    /**
     * Wake up every so often and resync to the RSS feed.
     */
    public void run()
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
            return;
        }
        
	while (!isApplicationClosing()) {
            setMessage("Updating...");
            flush();
            
            try {
                // parse the rss feed into a DOM
                Document doc = builder.parse(url);

                // update our text views
                update(views[0], 30, doc, "rss/channel/title");
                update(views[1], 24, doc, "rss/channel/item/title");
                update(views[2], 20, doc, "rss/channel/item/description");
            } catch (Exception e) {
                e.printStackTrace();
                setMessage("Error : " + e);
            }
            flush();

            // wait for an hour - see close()
            synchronized (this) {
                try {
                    wait(60 * 60 * 1000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    /**
     * Show a message in the middle of the screen.
     */
    void setMessage(String text)
    {
        views[1].setResource(createText("default-24.font", Color.white,
                                        text), RSRC_TEXT_WRAP);
    }

    /**
     * Update one of our views using the text found inside doc at path.
     */
    void update(View view, int size, Document doc, String path)
    {
        // Tweak the parent's background color, just for fun. This let's the
        // user know that the RSS feed was updated.
        int red   = random.nextInt(0x80);
        int green = random.nextInt(0x80);
        int blue  = random.nextInt(0x80);        
        view.getParent().setResource(new Color(red, green, blue));

        // Now update the view with the new text.
        String text = condense(getText(doc, path));
        view.setResource(createText("default-" + size + ".font", Color.white,
                                    text), RSRC_TEXT_WRAP);
    }
    
    //
    // animation handlers
    //

    /**
     * Listen for our custom event. When it fires, re-animate the corresponding
     * view.
     */
    public boolean handleEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
          case EVT_KEY: {
              HmeEvent.Key e = (HmeEvent.Key)event;
              switch (e.getCode()){
                case KEY_TIVO:
                  animate((int)e.getRawCode());
                  return true;
              }
          }
        }
        return super.handleEvent(event);
    }

    /**
     * Animate one of our views.
     */
    void animate(int index)
    {
        View view = views[index];
        int speed = 5000 + random.nextInt(5000);
        Resource anim = getResource("*" + speed);

        // move it
        int destX = random.nextInt(view.getParent().getWidth() - view.getWidth());
        int destY = random.nextInt(view.getParent().getHeight() - view.getHeight());
        view.setLocation(destX, destY, anim);

        // and send a special event so we wakeup when the animation is
        // complete
        HmeEvent evt = new HmeEvent.Key(getApp().getID(), 0,
                                        KEY_TIVO, index);
        sendEvent(evt, anim);
    }

    //
    // XML helpers
    //

    /**
     * A DOM helper which looks up "path" inside node n.
     */
    static String getText(Node n, String path)
    {
        // Are we done? Pull out the text.
        if (path.length() == 0) {
            return n.getFirstChild().getNodeValue();
        }

        // break path up into name/path
        String name;
        int slash = path.indexOf('/');
        if (slash == -1) {
            name = path;
            path = "";
        } else {
            name = path.substring(0, slash);
            path = path.substring(slash + 1);
        }

        // find the child and recurse
        NodeList children = n.getChildNodes();
        for (int i = children.getLength(); i--> 0;) {
            n = children.item(i);
            if (n.getNodeName().equals(name)) {
                return getText(n, path);
            }
        }

        return null;
    }

    /**
     * Clean up all the whitespace inside text and return the new string. All
     * whitespace runs are replaced with a single space.
     */
    static String condense(String text)
    {
        StringBuffer buf = new StringBuffer();
        StringTokenizer tokens = new StringTokenizer(text);
        while (tokens.hasMoreTokens()) {
            buf.append(tokens.nextToken());
            buf.append(' ');
        }
        return buf.substring(0, buf.length() - 1);
    }


    /**
     * Custom factory that reads the station name from the command line.
     */
    public static class WeatherFactory extends Factory
    {
        String station;

        /**
         * Create the factory - parse command line arguments.
         */
	protected void init(IArgumentList args)
	{
            try {
                station = "KSEA";
                args.checkForIllegalFlags();
                if (args.getRemainingCount() == 1) {
                    station = args.shift().toUpperCase();
                } else if (args.getRemainingCount() != 0) {
                    usage();
                }
            } catch (IArgumentList.BadArgumentException e) {
                usage();
            }
	}

        /**
         * Print usage and exit.
         */
        void usage()
        {
            System.err.println("Usage: Weather [<station>]");
            System.err.println("To get a list of city names, see:");
            System.err.println();
            System.err.println("  http://www.nws.noaa.gov/data/current_obs/");
            System.err.println();
            System.err.println("For example, 'Weather KSEA' will display Seattle's weather.");
            System.exit(1);
        }
    }
}
