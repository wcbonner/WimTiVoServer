//////////////////////////////////////////////////////////////////////
//
// File: SkullBones.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.skullbones;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.interfaces.ILogger;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.View;
import com.tivo.hme.sdk.util.Ticker;

/**
 *
 * This is a more complex example that shows an implementation
 * of a simple board game.
 *
 * The object of the game is to get 4 of your pieces in a row.
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class SkullBones extends Application implements Ticker.Client
{
    // This is the title of the application. The runtime environment will
    // discover the title here and use it as the name of the application.
    public final static String TITLE = "Skull and Bones";

    // The player names used in the scoreboard
    final static String[] PLAYER_NAME = { "Skulls", "Bones" };
    
    // Maximum number of players
    final static int NPLAYERS   = 2;

    // Messaging constants for timing and rendering
    final static int MESSAGE_TIME = 5000;
    final static int MESSAGE_HEIGHT = 32;

    // Game Type constants
    final static int INIT_GAME = -1;
    final static int ZERO_PLAYER = 0;
    final static int ONE_PLAYER = 1;
    final static int TWO_PLAYER = 3;
    final static int TURN_DELAY = 500;
    
    // The views used to render the game
    View content;              // Safe action area of screen
    MessageView messageView;   // for displaying messages
    SplashView  splash;        // for displaying the splash screen
    Board.Token cursor;        // for selecting a move
    Board board;               // the game board
    
    
    // the score for each player is kept here
    int score[] = new int[NPLAYERS];
    int nGamesTied;
    int round;          // how many rounds have been played
    int curPlayer = -1; // player 0 or player 1

    // this is true while the current game is ending
    boolean gameOver = false;

    int gameType = INIT_GAME;

    /**
     * Initialize the Application.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        View root = getRoot();

        
        //
        // create the content inset to the safe action bounds
        //
        content = new View(root, SAFE_ACTION_H, SAFE_ACTION_V,
                           root.getWidth() - (SAFE_ACTION_H * 2),
                           root.getHeight() - (SAFE_ACTION_V * 2));

        //
        // create board
        //
        board = new Board(content);

        splash = new SplashView();
    }


    /**
     * If a game is in progress respond to arrow keys to make a move. If the
     * splash screen is showing then look for a menu choice and start the game.
     * Keyboard input is ignored if the game is ending.
     */
    public boolean handleKeyPress(int code, long rawcode)
    {
        if (gameType == INIT_GAME) {
            switch (code) {
              case KEY_NUM0:
                gameType = ZERO_PLAYER;
                break;
              case KEY_NUM1:
                gameType = ONE_PLAYER;
                break;
              case KEY_NUM2:
                gameType = TWO_PLAYER;
                break;
              case KEY_TIVO:
                break;
              default:
                play("bonk.snd");
                break;
            }
            if (gameType != INIT_GAME) {
                play("select.snd");
                splash.fade();
            }
            return super.handleKeyPress(code, rawcode);
        }
        
        //
        // consume keyboard events in the zero player case
        //
        if (gameType == ZERO_PLAYER && !gameOver) {
            switch (code) {
              case KEY_LEFT:
              case KEY_RIGHT:
              case KEY_DOWN:
                return super.handleKeyPress(code, rawcode);
            }
        }

        if (!gameOver) {
            switch (code) {
              case KEY_LEFT:
                cursor.moveX(-1);
                break;
              case KEY_RIGHT:
                cursor.moveX(1);
                break;
              case KEY_DOWN:
                makeMove(cursor);
                break;
              case KEY_TIVO:
                //
                // This is the fake event we asked to be sent back to us when
                // the drop animation completes. It is currently the best way to
                // synchronize animation.
                //
                nextTurn();
                break;
            }
        }
        return super.handleKeyPress(code, rawcode);
    }

    /**
     * This ticker callback is used to remove messages that are displayed on top
     * of the board. Also, if the previous game has ended, this will kick off
     * the next round.
     */
    public long tick(long tm, Object arg)
    {
        //
        // If context is null the app has quit.
        //
        if (isApplicationClosing()) {
            return -1;
        }
        
        if (messageView != null) {
            messageView.remove();
            messageView = null;
        }

        //
        // If the game has ended start the next round.
        //
        if (gameOver) {
            gameOver = false;
            startRound();
        }

        flush();
        return -1;
    }

    /**
     * Show the given message for the default amount of time.
     */
    void showMessage(String message)
    {
        showMessage(message, MESSAGE_TIME);
    }

    /**
     * Show the given message for the specified amount of time.
     */
    void showMessage(String message, long duration)
    {
        log(ILogger.LOG_NOTICE, message);
        if (messageView != null) {
            messageView.remove();
        }

        messageView = new MessageView(content, 0, SAFE_ACTION_V,
                                      content.getWidth(),
                                      content.getHeight(), message);

        // trigger a ticker callback to clear the message
        Ticker.master.add(this, System.currentTimeMillis() + duration, null);
    }

    /**
     * This will start a new game (or round).
     */
    void startRound()
    {
        round++;
        board.clear();
        showMessage("Round: #" + round + "     " +
                    PLAYER_NAME[0] + ": " + score[0] +
                    "    " +
                    PLAYER_NAME[1] + ": " + score[1] +
                    "     Draw : " + nGamesTied);
        nextTurn();
    }

    /**
     * This is called to advance to the next player. 
     */
    void nextTurn()
    {
        curPlayer = (curPlayer + 1) % NPLAYERS;
        switch (gameType) {
          case ZERO_PLAYER:
            makeMove(board.createToken(board.bestMove(curPlayer), curPlayer));
            try {
                Thread.sleep(TURN_DELAY);
            } catch(InterruptedException e) {
            }
            break;

          case ONE_PLAYER:
            if (curPlayer == 1) {
                makeMove(board.createToken(board.bestMove(curPlayer), curPlayer));
                break;
            }
            // falling thru if it is the player's turn

          case TWO_PLAYER:
            cursor = board.createToken((cursor == null) ?
                                       0 : cursor.boardX, curPlayer);
        }
    }


    /**
     * Attempt to make a move by dropping the cursor from it's current location.
     *
     * If the game has ended, this method will just return.  If it is an invalid
     * move (that silo is full), then this will play a bonk sound and also
     * return.
     *
     * If the move can be made, it is checked to see if the piece is a winning
     * piece.
     *
     * If it is a winning piece, the win-game animation is played and the game
     * is advanced to the next round.
     *
     * If it is not a winning piece, then the game is advanced to the next turn.
     */
    void makeMove(Board.Token token)
    {
        //
        // prevent moving if the game is ending
        // prevent moving if a piece is animating
        // prevent moving if it is an invalid move
        //
        if (gameOver || token.isDropped()) return;
        if (!board.canMove(token.boardX)) {
            // play a bonk sound because this is an invalid move
            play("bonk.snd");
            return;
        }

        //
        // This is a valid move.
        //
        play(token.player == 0 ? "select.snd" : "updown.snd");

        //
        // Get the destination row for the token placed here
        //
        int boardY = board.getY(token.boardX);

        //
        // drop the token to make the move
        //
        token.drop(boardY);

        //
        // check for win or tie
        //
        if (board.isVictory(token)) {
            score[curPlayer]++;
            gameOver = true;
            play(curPlayer == 0 ? "thumbsup.snd" : "thumbsdown.snd");
            showMessage(PLAYER_NAME[curPlayer] + " Victory!", MESSAGE_TIME);
            board.dropTokens();
        } else if (board.isTieGame()) {
            gameOver = true;
            showMessage("Draw!");
            nGamesTied++;
        }
        
        // for debugging print the board out to stdOut
        // board.print();
    }

    
    /**
     * This view displays drop shadow text, and will dispose of the text
     * resources when it is removed.
     */
    static class MessageView extends View
    {
        View bg, fg;
        
        public MessageView(View parent, int x, int y, int w, int h, String message)
        {
            super(parent,x,y,w,h);
            // draw the text with a 2 pixel light gray drop shadow
            bg = new View(this, 2, 2, getWidth(), getHeight());
            fg = new View(this, 0, 0, getWidth(), getHeight());

            fg.setResource(getApp().createText("default-18-bold.font", "0xCCCC55", message),
                           RSRC_TEXT_WRAP | RSRC_VALIGN_TOP | RSRC_HALIGN_CENTER);
            bg.setResource(getApp().createText("default-18-bold.font", "0x111111", message),
                           RSRC_TEXT_WRAP | RSRC_VALIGN_TOP | RSRC_HALIGN_CENTER);
        }

        public void remove() {
            if(fg != null && fg.getResource() != null) {
                fg.getResource().remove();
            }

            if(bg != null && bg.getResource() != null) {
                bg.getResource().remove();
            }
            super.remove();
        }
    }
    
    /**
     * This class handles running a demo while the menu is displayed.
     * 
     **/
    class SplashView extends View implements Ticker.Client
    {
        int demoPlayer = -1;

        public SplashView()
        {
            super(content, 0, 0, content.getWidth(), content.getHeight());
            setResource("splash/scroll.png");

            // start the ticker to run a game demo
            Ticker.master.add(this, System.currentTimeMillis() + 1000, null);
        }

        void demoMove(Board.Token token)
        {
            if (!board.canMove(token.boardX)) {
                // don't let the demo cheat!
                return;
            }

            //
            // Get the destination row for the token placed here
            //
            int boardY = board.getY(token.boardX);

            //
            // drop the token to make the move
            //
            token.drop(boardY);
            if (board.isVictory(token) || board.isTieGame()) {
                board.clear();
            }
        }

        /**
         * fade is called when a menu choice has been selected.
         * It will kick off the game.
         */
        public void fade() {
            // drop the tokens and fade out
            splash.remove(getResource("*2000"));
            board.dropTokens();
            flush();

            // wait for that to finish, then change skins to the game skin
            try {
                Thread.sleep(2000);
            } catch(InterruptedException e) {
            }
            board.setSkin("");
            flush();
            
            //
            // start the game
            //
            startRound();
        }

        /**
         * make a move approximately every couple of seconds.
         */
        public long tick(long tm, Object arg)
        {
            //
            // If context is null the app has quit.
            //
            if (getContext() == null) {
                return -1;
            }
        
            //
            // Run a "demo" if the menu is showing
            //
            if (gameType == INIT_GAME) {
                demoPlayer = (demoPlayer + 1) % NPLAYERS;
                demoMove(board.createToken(board.bestMove(demoPlayer),demoPlayer));
                flush();
                return System.currentTimeMillis() + 1700;
            } 

            return -1;
        }
    }
}



