//////////////////////////////////////////////////////////////////////
//
// File: Board.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.skullbones;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.ImageResource;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * This extends the View class to implement the game board for the
 * Skull and Bones game.
 * 
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class Board extends View
{
    // board size
    final static int NCOL = 7;
    final static int NROW = 6;

    // The image resources used for the tokens on the board
    final static String[] TOKEN_IMAGE = { "skull.png", "bones.png" };

    // The game board dimensions
    final static int BOARD_WIDTH  = 494;
    final static int BOARD_HEIGHT = 366;

    // the size of the images
    final static int CELL_WIDTH = 70;
    final static int CELL_HEIGHT = 60;

    // animation times
    final static int DROP_TIME = 250;
    final static int CURSOR_TIME  = 200;
    
    // scanning constants
    final static int WINLEN  = 4;

    // represents a board position that has no tokens
    final static int EMPTY   = -1;

    View boardView;        // the view that contains the board
    Token board[][];       // the game board
    ArrayList winTokens;   // list of winning tokens

    // cache the images used for tokens here
    ImageResource playerImage[] = new ImageResource[SkullBones.NPLAYERS];

    // Random number generator
    Random rand = new Random();
    
    /**
     * Create a new empty board.
     */
    public Board(View parent)
    {
        super(parent,
              (parent.getWidth() - BOARD_WIDTH) / 2,
              parent.getHeight() - (BOARD_HEIGHT + CELL_HEIGHT),
              BOARD_WIDTH, (BOARD_HEIGHT + CELL_HEIGHT));


        // create a fg in the parent to hold the board image
        boardView = new View(parent, 0, 0, parent.getWidth(), parent.getHeight());

        // create the board and prepare for a game
        board = new Token[NCOL][NROW];
        clear();

        setSkin("splash");
    }

    /**
     * Change the current graphics set, disposing of old set if needed.
     * @param skin The directory that contains a set of game art resources.
     */
    void setSkin(String skin)
    {
        String pfx = ("".equals(skin)) ? "" : skin + "/";

        // set the board image from the skin directory
        boardView.setResource(pfx + "board.png", RSRC_VALIGN_BOTTOM);

        // cache the image resources used for tokens
        for (int i = 0; i < SkullBones.NPLAYERS; i++) {
            playerImage[i] = createImage(pfx + TOKEN_IMAGE[i]);
        }
    }

    /**
     * Clear the board to prepare for a new game.
     */
    void clear()
    {
        Resource anim = getResource("*" + (DROP_TIME * 3));

        // remove all tokens from the board 
        for (int x = 0; x < NCOL; x++) {
            for (int y = 0; y < NROW; y++) {
                if (board[x][y] != null) {
                    board[x][y].remove(anim);
                    board[x][y] = null;
                }
            }
        }

        // remove winning tokens from view hierarchy.
        if (winTokens != null) {
            Iterator e = winTokens.iterator();
            while (e.hasNext()) {
                ((Token)e.next()).remove(anim);
            }
            winTokens = null;
        }
    }

    /**
     * Animate non-winning tokens off the board
     */
    void dropTokens()
    {
        Resource anim = getResource("*" + (DROP_TIME * 5));
        for (int x = 0; x < NCOL; x++) {
            for (int y = 0; y < NROW; y++) {
                if (board[x][y] != null) {
                    board[x][y].remove(anim);
                    board[x][y] = null;
                }
            }
        }
    }
    
    /**
     * Returns the player or EMPTY for the given location.
     */
    int getPlayerID(int x, int y)
    {
        Token token = board[x][y];
        if (token != null) {
            return token.player;
        }
        return EMPTY;
    }

    /**
     * Create a token for the given player at the location.
     *
     * @param x the x coordinate in board coordinates
     * @param playerID either player 0 or player 1
     *
     * @return The new token
     */
    Token createToken(int x, int playerID)
    {
        return new Token(x, playerID);
    }
    
    /**
     * Returns the Token in location x, y.
     */
    Token getToken(int x, int y)
    {
        return board[x][y];
    }

    /**
     * Store the token into the game board.
     */
    void setToken(int x, int y, Token t)
    {
        board[x][y] = t;
    }

    /**
     * Check if any more moves can be made at all.
     */
    boolean isTieGame()
    {
        for (int i = 0; i < NCOL; i++) {
            if (canMove(i)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks to see if there is an empty space to move for the column specified
     * by x.
     * @param x the column to check
     * @return true if the move could be made
     */
    boolean canMove(int x)
    {
        return (getPlayerID(x, 0) == EMPTY);
    }


    /**
     * Returns the lowest empty cell in column X This would be the location of a
     * move for that column.
     *
     * @param x return the next movable Y from column X
     */
    int getY(int x)
    {
        for (int y = 0; y < NROW; y++) {
            if (getPlayerID(x, y) != EMPTY) {
                return y - 1;
            }
        }

        // the whole column was empty
        return NROW - 1;
    }

    /**
     * Determine if the given player's Token placed in location x, y would
     * result in that player winning the game.
     *
     * @param token the token that was just moved.
     */
    boolean isVictory(Token token)
    {
        int deltas[] = { -1, -1,
                          0, -1,
                          1, -1,
                          1,  0 };
        
        for (int i = 0; i < deltas.length; i += 2) {
            if (isVictory(token.boardX, token.boardY,
                          deltas[i], deltas[i + 1], token.player)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check for victory along the axis defined by x, y and dx, dy.  If there is
     * a winner, the winning tokens are removed from the board to prepare for
     * the end-round animation.
     *
     * @param x the minimum x position to check
     * @param y the minimum y position to check
     * @param dx the delta X for each axis to scan
     * @param dy the delta Y for each axis to scan
     * 
     * @return true if there is a winner
     */
    boolean isVictory(int x, int y, int dx, int dy, int player)
    {
        winTokens = new ArrayList();
        for (int i = 1 - WINLEN ; i < WINLEN; i++) {
            int scanX = x + (i * dx);
            int scanY = y + (i * dy);
            
            if ((scanX < 0 || scanX >= NCOL) ||
                (scanY < 0 || scanY >= NROW)) {
                //
                // if we are off the edge of the board clear winList
                //
                winTokens.clear();
            } else if (getPlayerID(scanX, scanY) == player) {
                //
                // This token belongs to the player, add it to the list of
                // winning tokens.
                //
                winTokens.add(getToken(scanX, scanY));
                if (winTokens.size() == WINLEN) {
                    //
                    // We have a winner! Prepare for the win animation by
                    // removing winning tokens from board so they won't be
                    // dropped out during the end round animation.
                    //
                    Iterator e = winTokens.iterator();
                    while (e.hasNext()) {
                        Token t = (Token)e.next();
                        setToken(t.boardX, t.boardY, null);
                    }
                    return true;
                }
            } else {
                //
                // this is either an empty space or enemy token.
                //
                winTokens.clear();
            }
        }
        winTokens = null;
        return false;
    }

    boolean checkVictory(int x, int y, int player)
    {
        int deltas[] = { -1, -1,
                          0, -1,
                          1, -1,
                          1,  0 };

        for (int i = 0; i < deltas.length; i += 2) {
            int count = 0;
            for (int j = 1 - WINLEN ; j < WINLEN ; j++) {
                int tx = x + j*deltas[i];
                int ty = y + j*deltas[i+1];
                if ((tx < 0) || (ty < 0) || (tx >= NCOL) || (ty >= NROW) || getPlayerID(tx, ty) != player) {
                    count = 0;
                } else if (++count == WINLEN) {
                    return true;
                }
            }
        }
        return false;
    }

    int bestMove(int us)
    {
        // pick a winning move
        for (int x = 0 ; x < NCOL ; x++) {
            int y = getY(x);
            if (y < 0) {
                continue;
            }
            setToken(x, y, new Token(x, y, us));
            if (checkVictory(x, y, us)) {
                setToken(x, y, null);
                return x;
            }
            setToken(x, y, null);
        }

        // block a losing move
        int them = (us + 1) % 2;
        for (int x = 0 ; x < NCOL ; x++) {
            int y = getY(x);
            if (y < 0) {
                continue;
            }
            setToken(x, y, new Token(x, y, them));
            if (checkVictory(x, y, them)) {
                setToken(x, y, null);
                return x;
            }
            setToken(x, y, null);
        }

        // pick a good move
        int bestx = -1;
        int bestscore = -2;
        int start = Math.abs(rand.nextInt()) % NCOL;
        
        for (int i = 0 ; i < NCOL ; i++) {
            int x = (start + i) % NCOL;
            int y = getY(x);
            if (y < 0) {
                continue;
            }
            int score = 0;
            if (y > 0) {
                setToken(x, y, new Token(x, y, us));
                Token t = new Token(x, y-1, them);
                setToken(x, y-1, t);
                if (checkVictory(x, y-1, them)) {
                    // move would create an opportunity for them
                    score = -1;
                } else {
                    t.player = us;
                    if (checkVictory(x, y-1, us)) {
                        // move would create an opportunity for us
                        score = 1;
                    }
                }
                setToken(x, y-1, null);
                setToken(x, y, null);
            }

            if (score > bestscore) {
                bestx = x;
                bestscore = score;
            } else if (score == bestscore) {
                bestx = x;
                bestscore = score;
            }
        }
        return bestx;
    }

    /**
     * This class encapsulates a game token.
     */
    public class Token
    {
        final static int WIDTH  = 58;         // the size of a token
        final static int HEIGHT = 51;

        final static int BOARD_H_MARGIN = 2;  // used for positioning tokens
        final static int BOARD_V_MARGIN = 4;
        
        int player;              // The player who owns this token
        int boardX, boardY;      // board coordinates of this token
        View view;		 // view when the token is visible

        boolean dropped = false; // indicates if the token is animated
        
        /**
         * Creates a token in the top row (a cursor).
         * This token has not been added to the board.
         */
        public Token(int boardX, int player)
        {
            this.player = player;
            this.boardX = boardX;

            view = new View(Board.this,
                            (boardX * CELL_WIDTH),
                            (boardY * CELL_HEIGHT),
                            CELL_WIDTH, CELL_HEIGHT);
            // set the token to be the image of the player
            view.setResource(playerImage[player]);
        }
        
        /**
         * Creates a token in the top row (a cursor).
         * This token has not been added to the board.
         */
        public Token(int boardX, int boardY, int player)
        {
            this.player = player;
            this.boardX = boardX;
            this.boardY = boardY;
        }

        /**
         * Move the token as a cursor.
         * Advance the Token to the left (-1) or right (+1).
         */
        void moveX(int dx)
        {
            if (isDropped()) {
                return;
            }
            Resource anim = getResource("*" + CURSOR_TIME);
            boardX += dx;
            if (boardX < 0) {
                boardX = Board.NCOL - 1;
                anim = null;
            } else if (boardX >= Board.NCOL) {
                boardX = 0;
                anim = null;
            }
            view.setLocation(boardX * Board.CELL_WIDTH, 0, anim);
        }

        /**
         * @return true If the token is currently being dropped.
         **/
        boolean isDropped()
        {
            return dropped;
        }

        /**
         * Animate this token from it's current location to the bottom of the
         * screen.  This also adds the token to the board in the destination
         * coordinates.
         *
         * @param boardY The destination Y coordinate for this piece
         **/
        void drop(int boardY)
        {
            // start the dropping process
            dropped = true;
            this.boardY = boardY;

            // put the token into the board
            setToken(boardX, boardY, this);

            //
            // The animation time is scaled based on the distance the pieces are
            // falling so they will maintain a constant speed.
            //
            Resource animation = getResource("*" +
                                             ((DROP_TIME / NROW) *
                                              (boardY + 1)));

            // animate the cursor to below the bottom of the board
            view.setLocation(BOARD_H_MARGIN + (boardX * CELL_WIDTH),
                        BOARD_V_MARGIN + (boardY * CELL_HEIGHT) + CELL_HEIGHT,
                        animation);
//            
// for debugging
//            dumpBoard();
//            System.out.println("MOVED: " + this);
//            
            //
            // Tell the receiver to send this event when the dropping animation
            // is completed this will trigger the game to advance to the next
            // turn
            //
            HmeEvent evt = new HmeEvent.Key(getApp().getID(),
                                            KEY_PRESS, KEY_TIVO, 0);
            getApp().sendEvent(evt, animation);
         }

        void remove(Resource anim)
        {
            view.setTransparency(0.80f, anim);
            view.setLocation(view.getX(), Board.this.getHeight(), anim);
            view.remove(anim);
        }
    }

    
    //
    // for debugging
    //
    
    /**
     * Display a text represenation of the game board to standard out.
     */
    void dumpBoard()
    {
        System.out.println("=========");
        for (int y = 0; y < NROW; y++) {
            System.out.print("=");
            for (int x = 0; x < NCOL; x++) {
                switch(getPlayerID(x, y)) {
                  case EMPTY: System.out.print("."); break;
                  case 0: System.out.print("1"); break;
                  case 1: System.out.print("2"); break;
                }
            }
            System.out.println("=");
        }
        System.out.println("=========");
    }
}
