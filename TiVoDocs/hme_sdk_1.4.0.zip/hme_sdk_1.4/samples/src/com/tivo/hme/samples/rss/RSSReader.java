//////////////////////////////////////////////////////////////////////
// 
// File: RSSReader.java
// Author: avh
// Description: 
// 
// Copyright (c) 2004, 2005 TiVo Inc.
// 
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.rss;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class is a lightweight XML parser coded specifically for the news feeds
 * supported by this application.
 * 
 * NOTE: some articles contain HTML tags and escape sequences, it is a known issue
 *       with this parser. This is intended solely as an example for developers.
 * 
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 */

public class RSSReader extends Thread
{
    final static int DELAY = 2*60*60*1000;
    final static Random rand = new Random(System.currentTimeMillis());

    Vector feeds = new Vector();

    /**
     * An RSS feed.
     */
    public class Feed
    {
	String name;
        URL url;
	File file;
	
        Date date;
        Vector articles;
        String path;
        Article current;

        URL logo;
        String title;

        Feed(String name, URL url)
        {
	    this.name = name;
            this.url = url;
            File rssDirectory = new File("rssData");
            if (!rssDirectory.exists()) {
                rssDirectory.mkdir();
            }
	    this.file = new File(rssDirectory, name + ".xml");
	    this.articles = new Vector();
        }

	synchronized boolean update() throws IOException
	{
            // only update articles that are are old
	    if (file.exists() && (file.lastModified() + DELAY > System.currentTimeMillis())) {
		return false;
	    }

	    System.out.println("loading " + file + " from " + url);
	    InputStream in = url.openStream();
	    try {
		OutputStream out = new FileOutputStream(file);
		try {
		    byte buf[] = new byte[1024];
		    int n = in.read(buf, 0, buf.length);
		    while (n > 0) {
			out.write(buf, 0, n);
			n = in.read(buf, 0, buf.length);
		    }
		} finally {
		    out.close();
		}
	    } finally {
		in.close();
            }

	    return true;
	}

        synchronized void refresh() throws IOException
        {
	    if (file.canRead()) {
		InputStream in = new FileInputStream(file);
		try {
		    parseInput(new BufferedReader(new InputStreamReader(in)));
		} finally {
		    in.close();
		}
	    }
        }

        void parseInput(Reader reader) throws IOException
        {
            path = "";
            articles = new Vector();
            StringBuffer buf = new StringBuffer();
            while (true) {
                int ch = reader.read();
                if (ch < 0) {
                    break;
                }

                switch (ch) {
                  case '<':
                    if (buf.length() > 0) {
                        handleContent(buf.toString());
                        buf.setLength(0);
                    }
                    parseTag(reader);
                    break;
		  case '&': {
		      StringBuffer entbuf = new StringBuffer();
		      for (ch = reader.read() ; (ch >= 0) && (ch != ';') ; ch = reader.read()) {
			  entbuf.append((char)ch);
		      }
		      String entity = entbuf.toString();
		      if (entity.startsWith("#")) {
			  buf.append((char)Integer.parseInt(entity.substring(1)));
		      } else if ("amp".equals(entity)) {
			  buf.append('&');
		      } else if ("quot".equals(entity)) {
			  buf.append('"');
		      } else if ("semi".equals(entity)) {
			  buf.append(';');
		      } else if ("lt".equals(entity)) {
			  buf.append('<');
		      } else if ("gt".equals(entity)) {
			  buf.append('>');
		      } else if ("apos".equals(entity)) {
			  buf.append('\'');
		      } else {
			  buf.append('?');
		      }
		      break;
		  }
			
		  case '\t':
		  case '\r':
		  case '\n':
		    buf.append(' ');
		    break;
                  default:
                    buf.append((char)ch);
                    break;
                }
            }
        }

        void parseTag(Reader reader) throws IOException
        {
            int ch = reader.read();
            int type = '<';
            switch (ch) {
	      case '!':
		while ((ch >= 0) && (ch != '>')) {
		    ch = reader.read();
		}
		return;
              case '?':
              case '/':
                type = ch;
                ch = reader.read();
                break;
            }
            StringBuffer tag = new StringBuffer();
            for (; Character.isUnicodeIdentifierPart((char)ch) || (ch == ':') ; ch = reader.read()) {
                if (ch == ':') {
                    tag.setLength(0);
                } else {
                    tag.append((char)ch);
                } 
            }
            while (true) {
                for (; Character.isSpace((char)ch) ; ch = reader.read());
                if (ch == '?') {
                    ch = reader.read();
                }
                if (ch == '/') {
                    handleStart(tag.toString());
                    handleEnd(tag.toString());
                    break;
                }
                if (ch == '>') {
                    switch (type) {
                      case '<': handleStart(tag.toString()); break;
                      case '/': handleEnd(tag.toString()); break;
                    }
                    break;
                }
                StringBuffer att = new StringBuffer();
                for (; Character.isUnicodeIdentifierPart((char)ch) || (ch == ':') ; ch = reader.read()) {
                    att.append((char)ch);
                }
                if (ch == '=') {
                    ch = reader.read();
                }
                if (ch == '"') {
                    ch = reader.read();
                }
                StringBuffer val = new StringBuffer();
                for (; (ch != '"') && (ch >= 0) ; ch = reader.read()) {
                    val.append((char)ch);
                }
                if (ch == '"') {
                    ch = reader.read();
                }
            }
        }

        void handleStart(String tag) throws IOException
        {
            path = path + "/" + tag;
            //System.out.println("START: " + path);
            if (path.endsWith("/channel/item") || path.endsWith("/RDF/item")) {
                current = new Article();
            }
        }

        void handleContent(String content) throws IOException
        {
            if (path.endsWith("/image/url")) {
		int i = content.lastIndexOf('?');
                logo = new URL((i < 0) ? content : content.substring(0, i));
                //System.out.println("FEED LOGO: " + logo);
            } else if (path.endsWith("/image/title")) {
                title = content;
                //System.out.println("FEED TITLE: " + title);
            } else if ((current != null) && path.endsWith("/item/title")) {
                current.title = content.trim();
            } else if ((current != null) && path.endsWith("/item/description")) {
                current.description = content.trim();
            } else {
                //System.out.println("[" + content.trim() + "]");
            }
        }

        void handleEnd(String tag) throws IOException
        {
            if (!path.endsWith(tag)) {
                throw new IOException("mismatch tag: " + tag);
            }
            if (path.endsWith("/channel/item") || path.endsWith("/RDF/item")) {
                articles.addElement(current);
                current = null;
            }
            //System.out.println("END: " + path);
            int i = path.lastIndexOf('/');
            path = path.substring(0, i);
        }

        public synchronized Article pickArticle()
        {
            return (Article)articles.elementAt(Math.abs(rand.nextInt()) % articles.size());
        }

        void print()
        {
            System.out.println("-------------------------------");
            System.out.println("title: " + title);
            System.out.println("logo: " + logo);
            for (Enumeration e = articles.elements() ; e.hasMoreElements() ;) {
                System.out.println(e.nextElement());
            }
            System.out.println();
        }
    }

    /**
     * Article from an RSS feed.
     */
    public static class Article
    {
        String title = "<untitled>";
        String description = "";

        public String toString()
        {
            return "[" + title + " -- " + description + "]";
        }
    }

    /**
     * Create the RSS reader.
     */
    RSSReader()
    {
	start();
    }

    public synchronized void run()
    {
	System.out.println("RUNNING");
	try {
	    Thread.sleep(500);

	    while (true) {
		for (Enumeration e = feeds.elements() ; e.hasMoreElements() ;) {
		    Feed feed = (Feed)e.nextElement();
		    try {
			if (feed.update()) {
			    feed.refresh();
			}
			System.out.println(feed.title + ", " + feed.articles.size() + " articles");
		    } catch (IOException ee) {
			ee.printStackTrace();
		    }
		}
		System.out.println("SLEEPING");
		wait(30*60*1000);
		System.out.println("RUNNING");
	    }
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
    }

    /**
     * Add a feed.
     */
    public synchronized void add(String name, URL url) throws IOException
    {
	System.out.println("adding " + url);
	Feed feed = new Feed(name, url);
	feed.refresh();
        feeds.addElement(feed);
	notifyAll();
    }

    /**
     * Randomly pick a feed.
     */
    public synchronized Feed pickFeed()
    {
        return (Feed)feeds.elementAt(Math.abs(rand.nextInt()) % feeds.size());
    }

    /**
     * Print all feeds/articles.
     */
    public synchronized void print()
    {
        for (Enumeration e = feeds.elements() ; e.hasMoreElements() ;) {
            Feed feed = (Feed)e.nextElement();
            feed.print();
        }
    }
}
