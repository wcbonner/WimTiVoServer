//////////////////////////////////////////////////////////////////////
//
// File: TicTacToe.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.tictactoe;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;

/**
 * Play tictactoe.
 *
 * @author      Adam Doppelt
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 * @author      Jonathan Payne
 * @author      Steven Samorodin
 */
public class TicTacToe extends Application
{
    // a view to contain all the pieces
    View piecesView;

    // the origin of the pieces grid on screen
    int gridX, gridY;
    
    // the pieces themselves
    Piece pieces[][] = new Piece[3][3];

    // X/O tokens
    Resource tokens[] = new Resource[2];

    // number of elapsed moves 0-9
    int nMoves;

    public void init(IContext context) throws Exception
    {
        super.init(context);
        //
        // layout the screen
        //
        View root = getRoot();

        root.setResource("bg.jpg");
        piecesView = new View(root, 0, 0, getWidth(), getHeight());

        gridX = (getWidth() - 300) / 2;
        gridY = 130;
        
        View grid = new View(root, gridX - 5, gridY - 5, 310, 310);
        grid.setResource("grid.png");

        //
        // the X and O pieces
        //
        
        tokens[0]  = createText("default-72-bold.font", "0xffffff", "X");
        tokens[1]  = createText("default-72-bold.font", "0xffffff", "O");
    }

    public boolean handleKeyPress(int code, long rawcode)
    {
        if (code >= KEY_NUM1 && code <= KEY_NUM9) {
            int pos = code - KEY_NUM1;
            // convert pos to x/y and make a move
            makeMove(pos % 3, pos / 3);
            return true;
        }
        if (code == KEY_LEFT) {
            getApp().setActive(false);
            return true;
        }
        play("bonk.snd");
        return false;
    }

    void makeMove(int x, int y)
    {
        //
        // is this a valid move?
        //
        
        if (pieces[x][y] != null) {
            play("bonk.snd");
            return;
        }
        int player = (nMoves++) % 2;

        //
        // create the piece
        //

        pieces[x][y] = new Piece(piecesView,
                                 gridX + (x * 100), gridY + (y * 100),
                                 100, 100, player);

        //
        // is the game over?
        //

        boolean victory = isVictory();
        boolean draw = !victory && nMoves == 9;
        if (victory || draw) {
            // play a sound and flush to make sure it takes affect before the
            // sleep
            play(victory ? "tivo.snd" : "thumbsdown.snd");
            flush();

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) { }

            //
            // if this is a victory, explode the pieces
            // if this is a victory or a draw, make the pieces fade away
            //
            
            Resource anim = getResource("*1000");
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    View v = pieces[i][j];                    
                    if (v != null) {
                        if (victory) {
                            v.setLocation(v.getX() + (i - 1) * 400,
                                          v.getY() + (j - 1) * 300,
                                          anim);
                        }
                        v.setTransparency(1, anim);
                        v.remove(anim);
                        pieces[i][j] = null;
                    }
                }
            }
            nMoves = 0;
        }
    }

    /**
     * Returns true if there is a victory on the board.
     */
    boolean isVictory()
    {
        for (int i = 0; i < 3; ++i) {
            if (isVictoryRun(0, i, 1, 0) || isVictoryRun(i, 0, 0, 1)) {
                return true;
            }
        }
        return isVictoryRun(0, 0, 1, 1) || isVictoryRun(0, 2, 1, -1);
    }

    /**
     * Return true if there is a victory (three pieces in a row) starting at
     * ox,oy and proceeding according to dx,dy. This will highlight the winning
     * moves if there is a victory.
     */
    boolean isVictoryRun(int ox, int oy, int dx, int dy)
    {
        int x = ox;
        int y = oy;
        for (int i = 0; i < 3; ++i) {
            if (pieces[x][y] == null) {
                return false;
            }
            if (i > 0 && pieces[x][y].player != pieces[x - dx][y - dy].player) {
                return false;
            }
            x += dx;
            y += dy;
        }

        // yes - we win! highlight the pieces.
        x = ox;
        y = oy;
        for (int i = 0; i < 3; ++i) {
            pieces[x][y].setResource("0xffa000");
            x += dx;
            y += dy;
        }
        
        return true;
    }

    /**
     * An X or O piece. Notice that the X/O is placed in a child instead of in
     * the view itself. We do this so that we can highlight the background of
     * the piece later by calling setResource.
     */
    class Piece extends View
    {
        int player;

        Piece(View parent, int x, int y, int w, int h, int player)
        {
            super(parent, x, y, w, h);
            this.player = player;
            new View(this, 0, 0, w, h).setResource(tokens[player]);
        }
    }
}
