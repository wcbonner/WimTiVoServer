//////////////////////////////////////////////////////////////////////
//
// File: RSS.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.rss;

import java.awt.Color;
import java.awt.Image;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;

import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.Resource;
import com.tivo.hme.sdk.View;
import com.tivo.hme.sdk.util.Ticker;


/**
 * RSS News Reader for Tivo HME
 * 
 * This application demonstrates:
 *    1) pulling content from an RSS Feed
 *    2) Text Metrics and Layout on the application side
 *    3) Animation
 *    4) Using video backgrounds on the receiver, and jpg image in simulator
 *
 * @author      Arthur van Hoff
 * @author      Brigham Stevens
 */
public class RSS extends Application implements Ticker.Client
{

    /**
     * Of course a real RSS reader would provide a nice user interface on the PC
     * for picking news feeds, but for this sample code, this initializer block
     * will do.
     * 
     ***/
    static RSSReader rss;
    static {
        try {
            rss = new RSSReader();
            rss.add("bbc", new URL("http://news.bbc.co.uk/rss/newsonline_world_edition/front_page/rss091.xml"));
	    rss.add("slashdot", new URL("http://slashdot.org/index.rss"));
	    rss.add("nytimes", new URL("http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml"));
	    rss.add("news", new URL("http://news.com.com/2547-1_3-0-5.xml"));
	    rss.add("salon", new URL("http://www.salon.com/feed/RDF/salon_net.rdf"));
	    rss.add("volkskrant", new URL("http://volkskrant.nl/rss/laatstenieuws.rss"));
        } catch (Throwable e) {
            e.printStackTrace();
	}
    }

    // fonts for displaying content
    FontResource titleFont;
    FontResource articleFont;
    
    int delay;
    int count;
    View bg;
    View active[];
    boolean paused;
    View root;

    /**
     * Create the app.
     */
    public void init(IContext context) throws Exception
    {
        super.init(context);
        root = getRoot();
        delay = 5000;
        active = new View[100];
        root.setResource(Color.white);
        root.setResource("background.mpg");
        
        titleFont = (Resource.FontResource) createFont( "default.ttf", FONT_BOLD, 20,
                FONT_METRICS_BASIC | FONT_METRICS_GLYPH );
        
        articleFont = (Resource.FontResource) createFont( "default.ttf", FONT_PLAIN, 18,
                FONT_METRICS_BASIC | FONT_METRICS_GLYPH );
        titleFont.addHandler(this);
        articleFont.addHandler(this);
        
        //root.setResource("background.mpg");
        bg = new View(root, 0, 0, root.getWidth(), root.getHeight());
        View banner = new View(root, 0, 0, 640, 120);
        banner.setResource("banner.png");
    }
    

    /**
     * This must be called after we have received the metrics for the fonts
     **/
    void startFeed()
    {
        root.setPainting(false);
	View v = nextArticle();
	v.setLocation((640 - v.getWidth()) / 2, 50);
	v.setVisible(true);
        active[count++] = v;
	fill(0);
        root.setPainting(true);
        Ticker.master.add(this, System.currentTimeMillis(), null);
    }

    /**
     * A super easy way to count the number of lines in a string
     */
    int getLineCount(String text)
    {
        StringTokenizer st = new StringTokenizer(text, "\n");
        return st.countTokens();
    }

    /**
     * This selects a random article and lays out the contents
     * in a View.
     * 
     * @return a View containing the layed out article
     */
    View nextArticle()
    {
        // select our random article
        RSSReader.Feed feed = rss.pickFeed();
        RSSReader.Article article = feed.pickArticle();

        // get the font metrics for measuring the text from the font
        HmeEvent.FontInfo tfi = titleFont.getFontInfo();
        HmeEvent.FontInfo afi = articleFont.getFontInfo();

        int width = 640 - (SAFE_TITLE_H*2);
        int articleWidth = width;
        
        // this is the container for the combined elements of the news article.
        View v = new View(bg, 0, SAFE_TITLE_H, width, 100);
        v.setVisible(false);

        // for debugging the container if you want
	//v.setResource(Color.lightGray);

        // start growing the vertical size
        int y = 0;

        // create the logo view - it will be sized to fit the logo
        View logoView = new LogoView(feed.logo, v, 0, y, articleWidth, 60);

        // grow to count the logo height
        y += logoView.getHeight() + 5;

        // create title view, layout the text and resize title view
        // initial vertical size is irrelevant, the view is resized at the end of this block
        View titleView = new View(v, 0, y, articleWidth, 80);
        String titleFormatted = titleView.layoutText(tfi, article.title);
        int titleLineCount = getLineCount(titleFormatted);
        titleView.setSize(titleView.getWidth(), titleLineCount * (int)tfi.getHeight());

        // grow the contianer to include the title
        y += titleView.getHeight() + 5;

        // create the article view, layout the text and resize
        // initial vertical size is irrelevant, the view is resized at the end of this block
        View articleView = new View(v, 0, y, articleWidth, 80);
        String articleFormatted = articleView.layoutText(afi, article.description);
        int articleLineCount = getLineCount(articleFormatted);
        articleView.setSize(articleView.getWidth(), articleLineCount * (int)afi.getHeight());

        // grow the container to include the article text
        y += articleView.getHeight() + 5;

        // create a bit more whitespace between articles
        y += (int)tfi.getHeight();
        
        // resize the outer container view to fit the logo, title & article
        v.setSize(width, y);

        // populate the views with resources
        // NOTE: no longer necessary to specify RSRC_TEXT_WRAP
        // for text that already contains \n or \r
        titleView.setResource(createText(titleFont, Color.black, titleFormatted),
                              RSRC_HALIGN_LEFT | RSRC_VALIGN_CENTER);
        articleView.setResource(createText(articleFont, Color.black, articleFormatted),
                                RSRC_HALIGN_LEFT | RSRC_VALIGN_TOP);

	return v;
    }

    /**
     * This class sizes itself to fit the imageURL given to the constructor.
     * The images in this application are small
     */
    static class LogoView extends View
    {
        
        static Map imgCache = new HashMap();  // used for cacheing images

        public LogoView(URL imageURL, View parent, int x, int y, int width, int height)
        {
            super(parent, x, y, width, height);
            Image img = (Image)imgCache.get(imageURL.toString());
            if (img == null) {
                ImageIcon icon = new ImageIcon(imageURL);
                img = icon.getImage();
                imgCache.put(imageURL.toString(), img);
            }
            setSize(width, img.getHeight(null));
            setResource(img, RSRC_HALIGN_LEFT | RSRC_VALIGN_BOTTOM);
        }
    }

    /**
     * Ensure that the screen is filled with articles.
     * @param extra - the space to fill
     */
    void fill(int extra)
    {
        root.setPainting(false);
	Resource animation = getResource("*" + (delay*2));
        Resource animation2 = getResource("*1000");
	int margin = 5;
	int y = active[count-1].getY() + active[count-1].getHeight() + margin;
	while (y < 480 + extra) {

            // create the article and position it below the screen
	    View v = nextArticle();
	    v.setLocation((640 - v.getWidth()) / 2, y);

            if (count > 2) {
                // slowly fade in if there are plenty of articles
                v.setTransparency(1f);
                v.setTransparency(0f, animation);
            } else {
                // quickly fade in if there are only a few articles
                v.setTransparency(1f);
                v.setTransparency(0f, animation2);
            }
	    v.setVisible(true);
            
	    active[count++] = v;
	    y += v.getHeight() + margin;
	}
        // scroll the articles from their location to the top of the screen
        for (int i = 0 ; i < count ; i++) {
            active[i].setLocation(active[i].getX(), active[i].getY() - extra, animation2);
        }
        root.setPainting(true);
    }

    /**
     * Fade out top article.
     */
    void trim()
    {
        root.setPainting(false);
        View v = active[0];
        Resource animation2 = getResource("*1000");
        Resource animation = getResource("*" + delay);

        System.arraycopy(active, 1, active, 0, --count);
        v.setTransparency(1.0f, animation2);

        // this will remove the article completly, long after
        // it has finished fading out
        v.remove(animation);
        root.setPainting(true);
    }
    
    
    public boolean handleEvent(HmeEvent event)
    {
        switch (event.getOpCode()) {
          case EVT_FONT_INFO:
            // kick off the news feed after we have received the metrics
            if (titleFont.getFontInfo() != null && articleFont.getFontInfo()!=null) {
                startFeed();
            }
            break;
          case EVT_DEVICE_INFO:
            HmeEvent.DeviceInfo info = (HmeEvent.DeviceInfo)event;

            //
            // If we are running in the simulator display jpg.
            //
            if (((String)info.getMap().get("platform")).startsWith("sim-")) {
                root.setResource("background.jpg");
            }
            break;
        }        
        return super.handleEvent(event);
    }

    public long tick(long tm, Object arg)
    {
        if (!paused) {
            View v = active[0];
            int dist = v.getY() - (80 - v.getHeight());
            fill(dist);
            trim();
        }
        flush();
        return System.currentTimeMillis() + delay;
    }
    
    public boolean handleKeyPress(int code, long rawcode)
    {
        switch (code) {


            // QUIT THE APPLICATION WHEN LEFT is pressed
          case KEY_LEFT:
            setActive(false);
            break;


            // SIMULATOR: SPACEBAR
          case KEY_PAUSE:
            paused = !paused;
            break;
        }
        return false;
    }
}
