//////////////////////////////////////////////////////////////////////
//
// File: Transition.java
//
// Copyright (c) 2004, 2005 TiVo Inc.
//
//////////////////////////////////////////////////////////////////////

package com.tivo.hme.samples.transition;

import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;
import java.util.TimeZone;

import com.tivo.core.ds.TeDict;
import com.tivo.hme.interfaces.IContext;
import com.tivo.hme.sdk.Application;
import com.tivo.hme.sdk.HmeEvent;
import com.tivo.hme.sdk.View;

/**
 * Simple application to test new transition feature.
 * 
 */
public class Transition extends Application
{
    int       depth       = 0;
    int       entryColor  = -1;
    int       returnColor = -1;
    int       curColor    = 0;
    Color     colors[]    = { Color.red, Color.yellow,
			      Color.green, Color.blue };
    
    TextView  titleView;
    TextView  depthView;
    TextView  entryView;
    TextView  returnView;
    TextView  colorView;
    View      hilightView;
    View      colorViews[];
    TextView  hintsView;
    TextView  errorView;
    
    public Transition()
    {
    	super();
    }

    Calendar getMidnightGMT( int offsetDay )
    {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.DAY_OF_YEAR, offsetDay);
        return cal;
    }
    
    public void init(IContext context) throws Exception
    {
    	super.init(context);
    	
    	int x = SAFE_ACTION_H;
    	int w = getRoot().getWidth() - 2 * x;
    	
    	titleView = new TextView(getRoot(), x, SAFE_ACTION_V, w, 40);
    	titleView.setFont(createFont("default.ttf", Font.PLAIN, 30));
    	titleView.setForeground(getResource(Color.white));
    	titleView.setValue("HME Transition Test");
    	
    	depthView = new TextView(getRoot(), x, 70, w, 40);
    	depthView.setFont(createFont("default.ttf", Font.PLAIN, 20));
    	depthView.setForeground(getResource(Color.white));
    	depthView.setValue("");
    	
    	entryView = new TextView(getRoot(), x, 100, w/2-10, 40);
    	entryView.setFont(createFont("default.ttf", Font.PLAIN, 20));
    	entryView.setForeground(getResource(Color.white));
    	entryView.setValue("");
    	
    	returnView = new TextView(getRoot(), x+w/2+20, 100, w/2-10, 40);
    	returnView.setFont(createFont("default.ttf", Font.PLAIN, 20));
    	returnView.setForeground(getResource(Color.white));
    	returnView.setValue("");
    	
    	colorView = new TextView(getRoot(), x, 130, w, 40);
    	colorView.setFont(createFont("default.ttf", Font.PLAIN, 20));
    	colorView.setForeground(getResource(Color.white));
    	colorView.setValue("");
    	
    	hilightView = new View(getRoot(), 0, 0, 0, 0);
    	hilightView.setResource(getResource(Color.white));
    	updateHilight();
    	
    	colorViews = new View[colors.length];
    	for (int c=0; c<colors.length; c++)
    	{
    		x = SAFE_ACTION_H + 80;
    		w = getRoot().getWidth() - 2 * x;
    		int y = 180 + c * 50;
    		int h = 40;
    		colorViews[c] = new View(getRoot(), x, y, w, h);
    		colorViews[c].setResource(getResource(colors[c]));
    	}
    	
    	hintsView = new TextView(getRoot(), x, 400, w, 40);
    	hintsView.setFont(createFont("default.ttf", Font.PLAIN, 14));
    	hintsView.setForeground(getResource(Color.white));
    	hintsView.setValue("Move up and down to select a color.  " +
    	"Move left to go back, right to go forward.");
    	
    	errorView = new TextView(getRoot(), x, 440, w, 40);
    	errorView.setFont(createFont("default.ttf", Font.PLAIN, 18));
    	errorView.setForeground(getResource(Color.red));
    	errorView.setValue("");
    	
    }

    /**
     * We override handleEvent to catch the INIT_INFO event.
     */
    public boolean handleEvent(HmeEvent event)
    {
    	switch (event.getOpCode()) {
	    	case EVT_INIT_INFO: {
	    		HmeEvent.InitInfo info = (HmeEvent.InitInfo) event;
	    		// Now call the INIT_INFO event handler that we have defined.
	    		return handleInitInfo(info);
	    	}
    	}
    	return super.handleEvent(event);
    }

    /**
     * This method handles the incoming INIT_INFO event.  Here we
     * determine if we were entered via a "forward" transition or a
     * "back" transition (or possibly no transition at all).
     */
    public boolean handleInitInfo(HmeEvent.InitInfo info)
    {
    	System.out.println(info);
    	
    	TeDict args = info.getParams();
    	if ( args != null )
    	{    		
    		if ( args.countValues("entry") > 0 )
    		{
    			entryColor = args.getInt("entry", 0);
    		}
    		
    		if ( args.countValues("return") > 0 )
    		{
    			returnColor = args.getInt("return", 0);
    		}
    		
    		if ( args.countValues("depth") > 0 )
    		{
    			depth = args.getInt("depth", 0);
    		}
    	}
    	updateInits();
    	
    	byte mem[] = info.getMemento();
    	if ( mem.length > 0 ) {
    		curColor = (int) mem[0];
    		updateHilight();
    	}
    	return true;
    }
    
    public boolean handleKeyPress(int code, long rawcode)
    {
    	switch (code) {
	    	case KEY_UP:
	    		curColor = (curColor+colors.length-1) % colors.length;
	    		updateHilight();
	    		return true;
	    	case KEY_DOWN:
	    		curColor = (curColor+colors.length+1) % colors.length;
	    		updateHilight();
	    		return true;
	    	case KEY_RIGHT:
	    	{
	    		byte mem[] = new byte[1];
	    		mem[0] = (byte) curColor;
	    		TeDict params = new TeDict();
	    		params.add("entry", curColor );
	    		params.add("depth", depth+1 );
	    		transitionForward(getContext().getBaseURI().toString(), params, mem);
	    		return true;
	    	}
	    	case KEY_LEFT:
	    	{
	    		TeDict params = new TeDict();
	    		params.add("return", curColor );
	    		params.add("depth", depth-1 );
	    		transitionBack(params);
	    		return true;
	    	}
    	}
    	return super.handleKeyPress(code, rawcode);
    }

    public boolean handleApplicationError(int code, String text)
    {
    	errorView.setValue(text);
    	return true;
    }
    
    public void updateInits()
    {
    	depthView.setValue("Current depth is " + depth + ".");
    	
    	if ( entryColor < 0 )
    	{
    		entryView.setValue("No entry color.");
    		entryView.setForeground(getResource(Color.gray));
    	}
    	else
    	{
    		entryView.setValue(colors[entryColor]);
    		entryView.setForeground(getResource(colors[entryColor]));
    	}
    	if ( returnColor < 0 )
    	{
    		returnView.setValue("No return color");
    		returnView.setForeground(getResource(Color.gray));
    	}
    	else
    	{
    		returnView.setValue(colors[returnColor]);
    		returnView.setForeground(getResource(colors[returnColor]));
    	}
    }
    
    public void updateHilight()
    {
    	int x = SAFE_ACTION_H + 75;
    	int w = getRoot().getWidth() - 2 * x;
    	int y = 180 + curColor * 50 - 5;
    	int h = 50;
    	hilightView.setBounds(x, y, w, h, getResource("*250"));
    	colorView.setValue("The currently selected color is " +
			   colors[curColor]);
    	colorView.setForeground(getResource(colors[curColor]));
    }
    
}
